"""In-process state for the demo.

Deliberately volatile: restarting the server resets the scenario, which is what
you want when demoing. Swapping this module for a database is the only change
needed to persist state.

Holds the four things the research brief says must be visible to a human:
  * editable user memory (s.5, [7])
  * a staged-action queue, so nothing is sent/booked/submitted unconfirmed (s.5)
  * an audit log of every tool call and approval decision (s.5, safety)
  * the success metrics of s.7
"""
from __future__ import annotations

import itertools
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from . import seed

_lock = threading.Lock()
_ids = itertools.count(1)


def new_id(prefix: str) -> str:
    with _lock:
        return "%s-%04d" % (prefix, next(_ids))


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# Mutable copies of the seeded world
# ---------------------------------------------------------------------------
memory: Dict[str, Dict] = {uid: dict(m) for uid, m in seed.DEFAULT_MEMORY.items()}
mail: Dict[str, List[Dict]] = {uid: [dict(m) for m in msgs] for uid, msgs in seed.MAIL.items()}
calendar: Dict[str, List[Dict]] = {uid: [dict(e) for e in evs] for uid, evs in seed.CALENDAR.items()}
tickets: List[Dict] = [dict(t) for t in seed.TICKETS]
tasks: Dict[str, List[Dict]] = {u["id"]: [] for u in seed.USERS}
sent_items: Dict[str, List[Dict]] = {u["id"]: [] for u in seed.USERS}
leave_requests: List[Dict] = []
expense_claims: List[Dict] = []
documents_created: Dict[str, List[Dict]] = {u["id"]: [] for u in seed.USERS}

# run_id -> run record;  action_id -> staged action
runs: Dict[str, Dict] = {}
staged_actions: Dict[str, Dict] = {}
audit_log: List[Dict] = []
feedback: List[Dict] = []
# Messages the injection defence pulled out of the flow, for the Safety panel.
quarantine: List[Dict] = []


# ---------------------------------------------------------------------------
# Baselines for the productivity metric (brief s.7).  Minutes a person spends
# doing the task unaided, from the Discover-phase shadowing the brief describes.
# These are demo assumptions and are labelled as such in the UI.
# ---------------------------------------------------------------------------
BASELINE_MINUTES: Dict[str, int] = {
    "inbox_triage": 22,
    "draft_reply": 14,
    "follow_up": 18,
    "find_slot": 12,
    "schedule_meeting": 15,
    "meeting_brief": 25,
    "knowledge_qa": 16,
    "draft_document": 55,
    "summarise_document": 20,
    "spreadsheet_explain": 28,
    "raise_ticket": 9,
    "leave_request": 8,
    "expense_claim": 24,
    "create_tasks": 10,
    "daily_plan": 15,
    "explain_jargon": 7,
    "smalltalk": 1,
    "unsupported": 1,
}
# Time the person still spends with the assistant: reading and approving.
REVIEW_MINUTES: Dict[str, float] = {
    "draft_document": 8.0,
    "summarise_document": 3.0,
    "spreadsheet_explain": 3.0,
    "meeting_brief": 3.0,
    "inbox_triage": 2.5,
    "draft_reply": 2.0,
    "follow_up": 2.5,
    "knowledge_qa": 1.5,
    "expense_claim": 2.0,
    "leave_request": 1.0,
    "raise_ticket": 1.0,
    "find_slot": 1.0,
    "schedule_meeting": 1.5,
    "create_tasks": 1.5,
    "daily_plan": 2.0,
    "explain_jargon": 0.5,
    "smalltalk": 0.2,
    "unsupported": 0.2,
}


def log(event: str, user_id: str, **fields) -> Dict:
    """Append to the audit log. Every tool call and decision goes through here."""
    entry = {
        "id": new_id("log"),
        "at": now_iso(),
        "event": event,
        "user": user_id,
    }
    entry.update(fields)
    audit_log.append(entry)
    return entry


def user_mail(user_id: str) -> List[Dict]:
    return mail.setdefault(user_id, [])


def user_calendar(user_id: str) -> List[Dict]:
    return calendar.setdefault(user_id, [])


def user_memory(user_id: str) -> Dict:
    return memory.setdefault(user_id, {})


def find_message(user_id: str, needle: str) -> Optional[Dict]:
    """Loose match on id, sender or subject - how a person would refer to mail."""
    needle = (needle or "").strip().lower()
    if not needle:
        return None
    msgs = user_mail(user_id)
    for m in msgs:
        if m["id"].lower() == needle:
            return m
    for m in msgs:
        if needle in m["subject"].lower() or needle in m["from"].lower():
            return m
    # Fall back to word overlap so "the urgent one from Ayesha" still lands.
    words = [w for w in needle.split() if len(w) > 3]
    best, best_score = None, 0
    for m in msgs:
        hay = (m["subject"] + " " + m["from"]).lower()
        score = sum(1 for w in words if w in hay)
        if score > best_score:
            best, best_score = m, score
    return best if best_score > 0 else None


# ---------------------------------------------------------------------------
# Metrics (brief s.7: adoption, productivity, quality, experience, risk)
# ---------------------------------------------------------------------------
def metrics_snapshot() -> Dict:
    completed = [r for r in runs.values() if r.get("intent")]
    week_ago = datetime.now() - timedelta(days=7)

    def _recent(r: Dict) -> bool:
        try:
            return datetime.fromisoformat(r["started_at"]) >= week_ago
        except Exception:
            return True

    recent = [r for r in completed if _recent(r)]
    active_users = sorted({r["user"] for r in recent})

    saved = 0.0
    per_user: Dict[str, Dict] = {}
    per_intent: Dict[str, Dict] = {}
    for r in completed:
        intent = r["intent"]
        base = BASELINE_MINUTES.get(intent, 10)
        assisted = REVIEW_MINUTES.get(intent, 2.0)
        delta = max(0.0, base - assisted) if r.get("useful", True) else 0.0
        saved += delta
        u = per_user.setdefault(
            r["user"], {"tasks": 0, "minutes_saved": 0.0, "experience": seed.USERS_BY_ID.get(r["user"], {}).get("experience", "n/a")}
        )
        u["tasks"] += 1
        u["minutes_saved"] += delta
        i = per_intent.setdefault(intent, {"tasks": 0, "minutes_saved": 0.0, "baseline": base})
        i["tasks"] += 1
        i["minutes_saved"] += delta

    approved = [a for a in staged_actions.values() if a["status"] == "approved"]
    rejected = [a for a in staged_actions.values() if a["status"] == "rejected"]
    edited = [a for a in approved if a.get("edited")]
    decided = len(approved) + len(rejected)

    up = [f for f in feedback if f["rating"] == "up"]
    down = [f for f in feedback if f["rating"] == "down"]

    blocked = [e for e in audit_log if e["event"] in (
        "injection_blocked", "dlp_blocked", "permission_denied", "action_rejected", "scope_denied")]

    def _count(evt: str) -> int:
        return sum(1 for e in audit_log if e["event"] == evt)

    return {
        "adoption": {
            "weekly_active_users": len(active_users),
            "registered_users": len(seed.USERS),
            "tasks_total": len(completed),
            "tasks_this_week": len(recent),
            "tasks_per_active_user": round(len(recent) / len(active_users), 1) if active_users else 0.0,
            "repeat_users": sum(1 for u in per_user.values() if u["tasks"] >= 3),
            "per_user": per_user,
        },
        "productivity": {
            "minutes_saved": round(saved, 1),
            "hours_saved": round(saved / 60.0, 2),
            "per_intent": per_intent,
            "note": "Baselines are demo assumptions from the Discover phase, not measurements.",
        },
        "quality": {
            "actions_staged": len(staged_actions),
            "approved": len(approved),
            "rejected": len(rejected),
            "edited_before_approval": len(edited),
            "approval_rate": round(100.0 * len(approved) / decided, 1) if decided else None,
            "correction_rate": round(100.0 * len(edited) / len(approved), 1) if approved else None,
        },
        "experience": {
            "thumbs_up": len(up),
            "thumbs_down": len(down),
            "satisfaction_pct": round(100.0 * len(up) / (len(up) + len(down)), 1) if (up or down) else None,
            "comments": [f for f in feedback if f.get("comment")][-5:],
        },
        "risk": {
            "unsafe_actions_blocked": len(blocked),
            "prompt_injections_caught": _count("injection_blocked"),
            "dlp_blocks": _count("dlp_blocked"),
            "permission_denials": _count("permission_denied") + _count("scope_denied"),
            "actions_rejected_by_user": len(rejected),
            "quarantined_messages": len(quarantine),
            "audit_entries": len(audit_log),
        },
    }


def reset() -> None:
    """Restore the scenario without restarting the process."""
    global memory, mail, calendar, tickets, tasks, sent_items
    global leave_requests, expense_claims, documents_created
    memory = {uid: dict(m) for uid, m in seed.DEFAULT_MEMORY.items()}
    mail = {uid: [dict(m) for m in msgs] for uid, msgs in seed.MAIL.items()}
    calendar = {uid: [dict(e) for e in evs] for uid, evs in seed.CALENDAR.items()}
    tickets = [dict(t) for t in seed.TICKETS]
    tasks = {u["id"]: [] for u in seed.USERS}
    sent_items = {u["id"]: [] for u in seed.USERS}
    leave_requests = []
    expense_claims = []
    documents_created = {u["id"]: [] for u in seed.USERS}
    runs.clear()
    staged_actions.clear()
    audit_log.clear()
    feedback.clear()
    quarantine.clear()
