"""Tool registry - the connector layer of the brief's s.5 architecture.

Descriptors follow the shape the Model Context Protocol [10] uses: a name, a
plain-language description, typed parameters, and - the part that matters here -
a `side_effect` of "read" or "write".

    read  -> runs immediately
    write -> never runs on its own. It is staged as a pending action, shown to
             the person in full, and only executed after they press Approve.

That single distinction is the brief's "confirm before sending, booking,
submitting or deleting anything" rule, enforced in one place rather than
sprinkled through prompts.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Callable, Dict, List, Optional

from . import rag, safety, store
from .seed import COLLEAGUE_BUSY, JARGON, SPREADSHEETS, USERS_BY_ID

REGISTRY: Dict[str, Dict] = {}


def tool(name: str, title: str, description: str, side_effect: str, scope: str,
         system: str, params: Optional[Dict[str, str]] = None):
    def wrap(fn: Callable):
        REGISTRY[name] = {
            "name": name,
            "title": title,
            "description": description,
            "side_effect": side_effect,
            "scope": scope,
            "system": system,
            "params": params or {},
            "fn": fn,
        }
        return fn
    return wrap


def describe_all() -> List[Dict]:
    return [{k: v for k, v in t.items() if k != "fn"} for t in REGISTRY.values()]


def _parse(ts: str) -> datetime:
    return datetime.fromisoformat(ts)


# ===========================================================================
# READ TOOLS
# ===========================================================================
@tool("mail.list", "Read inbox", "List messages in the signed-in user's mailbox.",
      "read", "mail.read", "Mail", {"unread_only": "bool", "limit": "int"})
def mail_list(user_id: str, args: Dict) -> Dict:
    msgs = store.user_mail(user_id)
    if args.get("unread_only"):
        msgs = [m for m in msgs if m["unread"]]
    limit = int(args.get("limit") or 25)
    out = []
    for m in msgs[:limit]:
        # Every untrusted body is scanned before it can reach the reasoning step.
        scan = safety.scan_untrusted(m["body"], "email", user_id, m["id"])
        out.append({
            "id": m["id"], "from": m["from"], "subject": m["subject"],
            "received": m["received"], "unread": m["unread"],
            "importance": m["importance"], "external": m["external"],
            "awaiting_reply": m["awaiting_reply"], "waiting_days": m["waiting_days"],
            "body": scan["clean_text"],
            "safety_findings": scan["findings"],
            "quarantined": scan["blocked"],
        })
    return {"messages": out, "count": len(out)}


@tool("mail.get", "Open a message", "Open one message by id, sender or subject.",
      "read", "mail.read", "Mail", {"reference": "str"})
def mail_get(user_id: str, args: Dict) -> Dict:
    m = store.find_message(user_id, args.get("reference", ""))
    if not m:
        return {"found": False}
    scan = safety.scan_untrusted(m["body"], "email", user_id, m["id"])
    return {
        "found": True,
        "message": {**{k: v for k, v in m.items() if k != "body"}, "body": scan["clean_text"]},
        "safety_findings": scan["findings"],
        "quarantined": scan["blocked"],
    }


@tool("calendar.list", "Read calendar", "List the user's events over the next N days.",
      "read", "calendar.read", "Calendar", {"days": "int"})
def calendar_list(user_id: str, args: Dict) -> Dict:
    days = int(args.get("days") or 7)
    horizon = datetime.now() + timedelta(days=days)
    events = [e for e in store.user_calendar(user_id) if _parse(e["start"]) <= horizon]
    events.sort(key=lambda e: e["start"])
    return {"events": events, "count": len(events)}


@tool("calendar.find_slot", "Find a free slot",
      "Find times when the user and named colleagues are all free, inside working hours.",
      "read", "calendar.read", "Calendar",
      {"attendees": "list[str]", "duration_minutes": "int", "within_days": "int"})
def calendar_find_slot(user_id: str, args: Dict) -> Dict:
    duration = int(args.get("duration_minutes") or 30)
    within = int(args.get("within_days") or 5)
    attendees = args.get("attendees") or []

    mem = store.user_memory(user_id)
    start_h, end_h = _working_hours(mem.get("working_hours", "09:00-17:00"))

    busy: List[tuple] = [(_parse(e["start"]), _parse(e["end"])) for e in store.user_calendar(user_id)]
    for person in attendees:
        for block in COLLEAGUE_BUSY.get(person, []):
            busy.append((_parse(block["start"]), _parse(block["end"])))

    slots = []
    cursor = datetime.now().replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
    end_of_search = datetime.now() + timedelta(days=within)
    while cursor < end_of_search and len(slots) < 4:
        if cursor.weekday() < 5 and start_h <= cursor.hour < end_h:
            finish = cursor + timedelta(minutes=duration)
            if finish.hour <= end_h and not any(s < finish and cursor < e for s, e in busy):
                slots.append({
                    "start": cursor.isoformat(timespec="minutes"),
                    "end": finish.isoformat(timespec="minutes"),
                    "label": cursor.strftime("%a %d %b, %H:%M") + "-" + finish.strftime("%H:%M"),
                })
                cursor += timedelta(hours=2)   # spread suggestions out
                continue
        cursor += timedelta(minutes=30)

    return {"slots": slots, "duration_minutes": duration,
            "attendees": attendees, "working_hours": "%02d:00-%02d:00" % (start_h, end_h)}


def _working_hours(pref: str) -> tuple:
    import re
    m = re.search(r"(\d{1,2}):\d{2}\s*[-to]+\s*(\d{1,2}):\d{2}", pref or "")
    if m:
        return int(m.group(1)), int(m.group(2))
    return 9, 17


@tool("knowledge.search", "Search company documents",
      "Retrieve passages from approved company content the user is allowed to see, with citations.",
      "read", "knowledge.read", "Knowledge base", {"query": "str"})
def knowledge_search(user_id: str, args: Dict) -> Dict:
    return rag.search(args.get("query", ""), user_id)


@tool("sheets.read", "Read a spreadsheet", "Load a spreadsheet and compute simple statistics.",
      "read", "docs.read", "Spreadsheets", {"name": "str"})
def sheets_read(user_id: str, args: Dict) -> Dict:
    key = (args.get("name") or "q3-regional-sales").strip().lower()
    sheet = SPREADSHEETS.get(key) or SPREADSHEETS["q3-regional-sales"]
    groups = set(USERS_BY_ID.get(user_id, {}).get("groups", []))
    if not groups.intersection(sheet["groups"]):
        store.log("permission_denied", user_id, reason="sheet_acl", detail=sheet["name"])
        return {"found": False, "reason": "You do not have access to this file."}

    cols, rows = sheet["columns"], sheet["rows"]
    months = cols[1:4]
    analysis = []
    for row in rows:
        region, values, target = row[0], row[1:4], row[4]
        total = sum(values)
        change = (values[-1] - values[0]) / values[0] * 100.0 if values[0] else 0.0
        analysis.append({
            "region": region, "total": total, "target": target,
            "attainment_pct": round(total / target * 100.0, 1),
            "trend_pct": round(change, 1),
            "monthly": dict(zip(months, values)),
        })
    grand = sum(a["total"] for a in analysis)
    grand_target = sum(a["target"] for a in analysis)
    return {
        "found": True, "name": sheet["name"], "owner": sheet["owner"],
        "columns": cols, "rows": rows, "analysis": analysis,
        "total": grand, "target": grand_target,
        "attainment_pct": round(grand / grand_target * 100.0, 1),
    }


@tool("hr.leave_balance", "Check leave balance", "Read the user's annual leave balance.",
      "read", "knowledge.read", "HR system", {})
def hr_leave_balance(user_id: str, args: Dict) -> Dict:
    from .seed import LEAVE_BALANCES
    bal = dict(LEAVE_BALANCES.get(user_id, {}))
    booked_here = sum(r["days"] for r in store.leave_requests if r["user"] == user_id)
    bal["booked"] = bal.get("booked", 0) + booked_here
    bal["remaining"] = bal.get("entitlement", 0) + bal.get("carried_over", 0) - bal.get("taken", 0) - bal.get("booked", 0)
    return bal


@tool("expenses.list_receipts", "List unclaimed receipts",
      "List receipts captured from e-mail and the travel desk that are not yet claimed.",
      "read", "knowledge.read", "Expenses", {})
def expenses_list(user_id: str, args: Dict) -> Dict:
    from .seed import EXPENSE_ITEMS
    items = EXPENSE_ITEMS.get(user_id, [])
    return {"items": items, "total": round(sum(i["amount"] for i in items), 2),
            "currency": items[0]["currency"] if items else "USD"}


@tool("tickets.list", "List my tickets", "List the user's open service-desk tickets.",
      "read", "knowledge.read", "Service desk", {})
def tickets_list(user_id: str, args: Dict) -> Dict:
    mine = [t for t in store.tickets if t["user"] == user_id]
    return {"tickets": mine, "count": len(mine)}


@tool("glossary.lookup", "Look up an acronym", "Explain an internal acronym or piece of jargon.",
      "read", "knowledge.read", "Knowledge base", {"term": "str"})
def glossary_lookup(user_id: str, args: Dict) -> Dict:
    term = (args.get("term") or "").strip().lower().strip("?.,")
    if term in JARGON:
        return {"found": True, "term": term.upper(), "definition": JARGON[term]}
    for k, v in JARGON.items():
        if term and (term in k or k in term):
            return {"found": True, "term": k.upper(), "definition": v}
    return {"found": False, "term": term, "known_terms": sorted(JARGON.keys())}


@tool("tasks.list", "List my tasks", "List the user's assistant-created to-do items.",
      "read", "knowledge.read", "Tasks", {})
def tasks_list(user_id: str, args: Dict) -> Dict:
    return {"tasks": store.tasks.setdefault(user_id, [])}


# ===========================================================================
# WRITE TOOLS - staged, never auto-run
# ===========================================================================
@tool("mail.send", "Send an e-mail", "Send a message from the user's mailbox.",
      "write", "mail.send", "Mail",
      {"to": "list[str]", "subject": "str", "body": "str", "_in_reply_to": "str (internal)"})
def mail_send(user_id: str, args: Dict) -> Dict:
    record = {
        "id": store.new_id("sent"),
        "to": args.get("to", []),
        "subject": args.get("subject", ""),
        "body": args.get("body", ""),
        "sent_at": store.now_iso(),
    }
    store.sent_items.setdefault(user_id, []).append(record)
    ref = args.get("_in_reply_to")
    if ref:
        for m in store.user_mail(user_id):
            if m["id"] == ref:
                m["awaiting_reply"] = False
                m["unread"] = False
    return {"sent": True, "message": record,
            "receipt": "Sent to %s" % ", ".join(record["to"])}


@tool("calendar.create_event", "Create a calendar event", "Put a meeting in the diary and invite attendees.",
      "write", "calendar.write", "Calendar",
      {"title": "str", "start": "str", "end": "str", "attendees": "list[str]", "notes": "str"})
def calendar_create(user_id: str, args: Dict) -> Dict:
    event = {
        "id": store.new_id("evt"),
        "title": args.get("title", "Meeting"),
        "start": args.get("start"),
        "end": args.get("end"),
        "attendees": args.get("attendees", []),
        "notes": args.get("notes", ""),
        "created_by": "assistant",
    }
    store.user_calendar(user_id).append(event)
    store.user_calendar(user_id).sort(key=lambda e: e["start"])
    return {"created": True, "event": event,
            "receipt": "%s booked, invites sent to %s" % (event["title"], ", ".join(event["attendees"]) or "you")}


@tool("tickets.create", "Raise a service-desk ticket", "Open an IT or facilities ticket.",
      "write", "tickets.write", "Service desk",
      {"title": "str", "description": "str", "priority": "str", "category": "str"})
def tickets_create(user_id: str, args: Dict) -> Dict:
    ticket = {
        "id": "INC-%05d" % (40218 + len(store.tickets) + 1),
        "user": user_id,
        "title": args.get("title", "Request"),
        "description": args.get("description", ""),
        "priority": args.get("priority", "P3"),
        "category": args.get("category", "General"),
        "status": "Submitted",
        "opened": store.now_iso(),
    }
    store.tickets.append(ticket)
    return {"created": True, "ticket": ticket,
            "receipt": "%s raised at %s" % (ticket["id"], ticket["priority"])}


@tool("hr.request_leave", "Submit a leave request", "Send an annual leave request to the user's manager.",
      "write", "hr.leave.write", "HR system",
      {"start_date": "str", "end_date": "str", "days": "int", "note": "str"})
def hr_request_leave(user_id: str, args: Dict) -> Dict:
    req = {
        "id": store.new_id("leave"),
        "user": user_id,
        "start_date": args.get("start_date"),
        "end_date": args.get("end_date"),
        "days": int(args.get("days") or 1),
        "note": args.get("note", ""),
        "approver": USERS_BY_ID.get(user_id, {}).get("manager", "Line manager"),
        "status": "Pending manager approval",
        "submitted": store.now_iso(),
    }
    store.leave_requests.append(req)
    return {"created": True, "request": req,
            "receipt": "%d day(s) requested, awaiting %s" % (req["days"], req["approver"])}


@tool("expenses.submit_claim", "Submit an expense claim", "Submit a claim built from captured receipts.",
      "write", "expenses.write", "Expenses",
      {"items": "list[dict]", "total": "float", "purpose": "str"})
def expenses_submit(user_id: str, args: Dict) -> Dict:
    claim = {
        "id": store.new_id("claim"),
        "user": user_id,
        "items": args.get("items", []),
        "total": args.get("total", 0.0),
        "currency": "USD",
        "purpose": args.get("purpose", ""),
        "status": "Pending manager approval",
        "submitted": store.now_iso(),
    }
    store.expense_claims.append(claim)
    return {"created": True, "claim": claim,
            "receipt": "Claim %s for USD %.2f submitted" % (claim["id"], claim["total"])}


@tool("tasks.create", "Add to-do items", "Add items to the user's task list.",
      "write", "tasks.write", "Tasks", {"items": "list[str]", "due": "str"})
def tasks_create(user_id: str, args: Dict) -> Dict:
    created = []
    for title in args.get("items", []):
        t = {"id": store.new_id("task"), "title": title,
             "due": args.get("due", ""), "done": False, "created": store.now_iso()}
        store.tasks.setdefault(user_id, []).append(t)
        created.append(t)
    return {"created": True, "tasks": created, "receipt": "%d task(s) added" % len(created)}


@tool("docs.create", "Save a document", "Save a drafted document to the user's workspace.",
      "write", "docs.write", "Documents", {"title": "str", "body": "str", "format": "str"})
def docs_create(user_id: str, args: Dict) -> Dict:
    doc = {
        "id": store.new_id("doc"),
        "title": args.get("title", "Untitled"),
        "format": args.get("format", "document"),
        "body": args.get("body", ""),
        "created": store.now_iso(),
    }
    store.documents_created.setdefault(user_id, []).append(doc)
    return {"created": True, "document": doc, "receipt": "Saved as '%s'" % doc["title"]}


# ===========================================================================
# Invocation
# ===========================================================================
def call_read(name: str, user_id: str, args: Dict) -> Dict:
    """Run a read tool after checking the delegated scope."""
    spec = REGISTRY[name]
    if spec["side_effect"] != "read":
        raise ValueError("%s is a write tool - it must be staged for approval" % name)
    gate = safety.check_scope(user_id, spec["scope"], spec["title"])
    if not gate["allowed"]:
        store.log("tool_denied", user_id, tool=name, reason=gate["reason"])
        return {"_denied": True, "reason": gate["reason"]}
    result = spec["fn"](user_id, args)
    store.log("tool_read", user_id, tool=name, system=spec["system"],
              detail=_summarise_args(args))
    return result


def execute_write(name: str, user_id: str, args: Dict) -> Dict:
    """Run a write tool. Only ever called from the approval endpoint."""
    spec = REGISTRY[name]
    gate = safety.check_scope(user_id, spec["scope"], spec["title"])
    if not gate["allowed"]:
        return {"_denied": True, "reason": gate["reason"]}
    result = spec["fn"](user_id, args)
    store.log("tool_write", user_id, tool=name, system=spec["system"],
              detail=result.get("receipt", ""))
    return result


def _summarise_args(args: Dict) -> str:
    bits = []
    for k, v in (args or {}).items():
        s = str(v)
        bits.append("%s=%s" % (k, s[:40] + "..." if len(s) > 40 else s))
    return ", ".join(bits)
