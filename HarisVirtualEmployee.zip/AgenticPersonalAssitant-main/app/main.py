"""HTTP API + static front end.

Route groups mirror the reference architecture in s.5 of the research brief:

    /api/session      identity & delegated permissions
    /api/chat         the orchestrator
    /api/actions/*    the confirmation gate
    /api/memory       user-visible, editable memory
    /api/knowledge    the RAG corpus this user can see
    /api/safety       quarantine + audit log
    /api/metrics      the s.7 success measures
"""
from __future__ import annotations

from typing import Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import llm, orchestrator, rag, safety, seed, store, tools
from .config import WEB_DIR, settings

app = FastAPI(
    title="Aide - AI Personal Assistant for Non-Technical Employees",
    description="Mock implementation of the reference architecture in research brief 8 of 8.",
    version="1.0.0",
)


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------
class ChatRequest(BaseModel):
    user_id: str = Field(..., description="Signed-in user; the assistant acts only as them.")
    message: str


class ApproveRequest(BaseModel):
    edits: Optional[Dict[str, str]] = None


class RejectRequest(BaseModel):
    reason: Optional[str] = ""


class MemoryRequest(BaseModel):
    user_id: str
    key: str
    value: str


class FeedbackRequest(BaseModel):
    user_id: str
    run_id: Optional[str] = None
    rating: str                      # "up" | "down"
    comment: Optional[str] = ""


def _require_user(user_id: str) -> Dict:
    user = seed.USERS_BY_ID.get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="Unknown user '%s'." % user_id)
    return user


# ---------------------------------------------------------------------------
# Session & identity
# ---------------------------------------------------------------------------
@app.get("/api/config")
def get_config() -> Dict:
    return {
        "product": "Aide",
        "engine": settings.effective_engine,
        "llm_mode": settings.llm_mode,
        "live_llm_available": settings.live_llm_available,
        "guardrails": {
            "confirm_before_acting": settings.confirm_before_acting,
            "prompt_injection_defence": settings.prompt_injection_defence,
            "dlp": settings.dlp,
        },
        "tools": tools.describe_all(),
    }


@app.get("/api/users")
def list_users() -> Dict:
    return {"users": [
        {k: v for k, v in u.items()} | {"hidden_documents": safety.hidden_document_count(u["id"])}
        for u in seed.USERS
    ]}


@app.get("/api/session/{user_id}")
def session(user_id: str) -> Dict:
    user = _require_user(user_id)
    granted = set(user["scopes"])
    all_scopes = sorted({t["scope"] for t in tools.REGISTRY.values()})
    return {
        "user": user,
        "permissions": [
            {"scope": s, "granted": s in granted,
             "tools": [t["title"] for t in tools.REGISTRY.values() if t["scope"] == s]}
            for s in all_scopes
        ],
        "knowledge": rag.corpus_stats(user_id),
        "memory": store.user_memory(user_id),
        "quick_actions": QUICK_ACTIONS.get(user["department"], QUICK_ACTIONS["_default"]),
        "prompt_library": PROMPT_LIBRARY.get(user["department"], PROMPT_LIBRARY["_default"]),
    }


# ---------------------------------------------------------------------------
# Chat
# ---------------------------------------------------------------------------
@app.post("/api/chat")
def chat(req: ChatRequest) -> Dict:
    _require_user(req.user_id)
    if not req.message.strip():
        raise HTTPException(status_code=400, detail="Empty message.")
    return orchestrator.handle(req.user_id, req.message.strip())


# ---------------------------------------------------------------------------
# The confirmation gate
# ---------------------------------------------------------------------------
@app.get("/api/actions")
def list_actions(user_id: str, status: Optional[str] = None) -> Dict:
    acts = [a for a in store.staged_actions.values() if a["user"] == user_id]
    if status:
        acts = [a for a in acts if a["status"] == status]
    acts.sort(key=lambda a: a["created_at"], reverse=True)
    return {"actions": acts, "pending": sum(1 for a in acts if a["status"] == "pending")}


@app.post("/api/actions/{action_id}/approve")
def approve_action(action_id: str, req: ApproveRequest) -> JSONResponse:
    result = orchestrator.approve(action_id, req.edits)
    return JSONResponse(result, status_code=200 if result["ok"] else 400)


@app.post("/api/actions/{action_id}/reject")
def reject_action(action_id: str, req: RejectRequest) -> JSONResponse:
    result = orchestrator.reject(action_id, req.reason or "")
    return JSONResponse(result, status_code=200 if result["ok"] else 400)


# ---------------------------------------------------------------------------
# Memory (brief s.5 / MemGPT [7]) - visible and editable by the person
# ---------------------------------------------------------------------------
@app.get("/api/memory/{user_id}")
def get_memory(user_id: str) -> Dict:
    _require_user(user_id)
    return {"memory": store.user_memory(user_id)}


@app.post("/api/memory")
def set_memory(req: MemoryRequest) -> Dict:
    _require_user(req.user_id)
    mem = store.user_memory(req.user_id)
    old = mem.get(req.key)
    mem[req.key] = req.value
    store.log("memory_updated", req.user_id, detail="%s: %r -> %r" % (req.key, old, req.value))
    return {"ok": True, "memory": mem}


@app.delete("/api/memory/{user_id}/{key}")
def forget(user_id: str, key: str) -> Dict:
    _require_user(user_id)
    mem = store.user_memory(user_id)
    removed = mem.pop(key, None)
    store.log("memory_forgotten", user_id, detail="%s (was %r)" % (key, removed))
    return {"ok": True, "memory": mem}


# ---------------------------------------------------------------------------
# Knowledge, mailbox and workspace views
# ---------------------------------------------------------------------------
@app.get("/api/knowledge/{user_id}")
def knowledge(user_id: str) -> Dict:
    _require_user(user_id)
    visible = safety.visible_documents(user_id)
    return {
        "documents": [
            {"id": d["id"], "title": d["title"], "owner": d["owner"],
             "last_reviewed": d["last_reviewed"], "url": d["url"],
             "groups": d["groups"], "stale": rag._is_stale(d["last_reviewed"]),
             "words": len(d["text"].split())}
            for d in visible
        ],
        "withheld": safety.hidden_document_count(user_id),
        "stats": rag.corpus_stats(user_id),
    }


@app.get("/api/workspace/{user_id}")
def workspace(user_id: str) -> Dict:
    _require_user(user_id)
    return {
        "inbox": [{k: v for k, v in m.items() if k != "body"} for m in store.user_mail(user_id)],
        "sent": store.sent_items.get(user_id, []),
        "calendar": store.user_calendar(user_id),
        "tasks": store.tasks.get(user_id, []),
        "tickets": [t for t in store.tickets if t["user"] == user_id],
        "leave_requests": [r for r in store.leave_requests if r["user"] == user_id],
        "expense_claims": [c for c in store.expense_claims if c["user"] == user_id],
        "documents": store.documents_created.get(user_id, []),
    }


# ---------------------------------------------------------------------------
# Safety & audit
# ---------------------------------------------------------------------------
@app.get("/api/safety")
def safety_view(user_id: Optional[str] = None, limit: int = 100) -> Dict:
    log = store.audit_log
    quar = store.quarantine
    if user_id:
        log = [e for e in log if e["user"] == user_id]
        quar = [q for q in quar if q["user"] == user_id]
    return {
        "quarantine": list(reversed(quar))[:limit],
        "audit_log": list(reversed(log))[:limit],
        "guardrails": {
            "confirm_before_acting": settings.confirm_before_acting,
            "prompt_injection_defence": settings.prompt_injection_defence,
            "dlp": settings.dlp,
        },
    }


# ---------------------------------------------------------------------------
# Measurement (brief s.7)
# ---------------------------------------------------------------------------
@app.get("/api/metrics")
def metrics() -> Dict:
    return store.metrics_snapshot()


@app.post("/api/feedback")
def post_feedback(req: FeedbackRequest) -> Dict:
    _require_user(req.user_id)
    if req.rating not in ("up", "down"):
        raise HTTPException(status_code=400, detail="rating must be 'up' or 'down'")
    entry = {
        "id": store.new_id("fb"),
        "user": req.user_id,
        "run_id": req.run_id,
        "rating": req.rating,
        "comment": (req.comment or "").strip(),
        "at": store.now_iso(),
    }
    store.feedback.append(entry)
    run = store.runs.get(req.run_id or "")
    if run:
        run["useful"] = req.rating == "up"
    store.log("feedback", req.user_id, detail="%s %s" % (req.rating, entry["comment"][:80]))
    return {"ok": True, "feedback": entry}


@app.post("/api/reset")
def reset() -> Dict:
    store.reset()
    return {"ok": True, "message": "Scenario reset."}


# ---------------------------------------------------------------------------
# Role-specific one-click actions and prompt library (brief s.6 enablement:
# "ready-made prompt templates and one-click actions, so no prompting skill
# is needed").
# ---------------------------------------------------------------------------
QUICK_ACTIONS: Dict[str, List[Dict]] = {
    "_default": [
        {"label": "Summarise my inbox", "icon": "inbox", "prompt": "Summarise my inbox"},
        {"label": "Plan my day", "icon": "sun", "prompt": "Plan my day"},
        {"label": "Chase unanswered", "icon": "clock", "prompt": "Chase the threads waiting on my reply"},
        {"label": "Ask about a policy", "icon": "book", "prompt": "What is our travel policy for international trips?"},
        {"label": "Raise an IT ticket", "icon": "wrench", "prompt": "Raise a ticket - my monitor is dead and I cannot work"},
        {"label": "Book leave", "icon": "palm", "prompt": "Book 3 days of annual leave"},
    ],
    "People": [
        {"label": "Summarise my inbox", "icon": "inbox", "prompt": "Summarise my inbox"},
        {"label": "Plan my day", "icon": "sun", "prompt": "Plan my day"},
        {"label": "Schedule the panel", "icon": "calendar", "prompt": "Schedule a 90 minute meeting with Ayesha Khan and Marek Nowak about the grievance panel"},
        {"label": "Reply to Sam", "icon": "pen", "prompt": "Draft a reply to Sam Li about carrying leave into next year"},
        {"label": "Leave carry-over rule", "icon": "book", "prompt": "What is our carry-over rule for annual leave?"},
        {"label": "Chase unanswered", "icon": "clock", "prompt": "Chase the threads waiting on my reply"},
    ],
    "Finance": [
        {"label": "Summarise my inbox", "icon": "inbox", "prompt": "Summarise my inbox"},
        {"label": "Explain the Q3 sheet", "icon": "chart", "prompt": "Explain the Q3 regional sales spreadsheet and the trend"},
        {"label": "Submit my expenses", "icon": "receipt", "prompt": "Submit my outstanding expense claim"},
        {"label": "Discount approval rule", "icon": "book", "prompt": "Who approves a 28 percent discount?"},
        {"label": "Month-end checklist", "icon": "list", "prompt": "Summarise the month-end close checklist"},
        {"label": "Plan my day", "icon": "sun", "prompt": "Plan my day"},
    ],
    "Revenue": [
        {"label": "Summarise my inbox", "icon": "inbox", "prompt": "Summarise my inbox"},
        {"label": "Pipeline review brief", "icon": "clipboard", "prompt": "Prepare me a brief for the pipeline review"},
        {"label": "Discount approval rule", "icon": "book", "prompt": "What discount can I approve without going to Finance?"},
        {"label": "Draft a deal memo", "icon": "pen", "prompt": "Draft a memo about the Fairhaven renewal commercials"},
        {"label": "Find a slot with Chris", "icon": "calendar", "prompt": "Find a 30 minute slot with Chris Bell"},
        {"label": "Plan my day", "icon": "sun", "prompt": "Plan my day"},
    ],
    "Operations": [
        {"label": "Summarise my inbox", "icon": "inbox", "prompt": "Summarise my inbox"},
        {"label": "What does MEC mean?", "icon": "book", "prompt": "What does MEC stand for?"},
        {"label": "My first two weeks", "icon": "compass", "prompt": "What should I be doing in my first two weeks?"},
        {"label": "Book time with my manager", "icon": "calendar", "prompt": "Find a 45 minute slot with Ayesha Khan"},
        {"label": "Raise an IT ticket", "icon": "wrench", "prompt": "Raise a ticket - my second monitor is not detected"},
        {"label": "Plan my day", "icon": "sun", "prompt": "Plan my day"},
    ],
    "Study": [
        {"label": "Plan my study day", "icon": "sun", "prompt": "Plan my day"},
        {"label": "Summarise my inbox", "icon": "inbox", "prompt": "Summarise my inbox"},
        {"label": "Reply to my guide", "icon": "pen", "prompt": "Draft a reply to Anand Rao about the paper draft"},
        {"label": "My JFSD plan", "icon": "book", "prompt": "What is the plan for the JFSD elective?"},
        {"label": "Book time with my guide", "icon": "calendar", "prompt": "Find a 30 minute slot with Anand Rao"},
        {"label": "Chase unanswered", "icon": "clock", "prompt": "Chase the threads waiting on my reply"},
    ],
}

PROMPT_LIBRARY: Dict[str, List[Dict]] = {
    "_default": [
        {"group": "Mail", "items": [
            "Summarise my inbox",
            "Draft a reply to the most urgent message",
            "Chase the threads waiting on my reply",
        ]},
        {"group": "Diary", "items": [
            "Find a 30 minute slot with Ayesha Khan",
            "Prepare me a brief for my next meeting",
        ]},
        {"group": "Company questions", "items": [
            "What is our travel policy for international trips?",
            "How much notice do I need for 5 days of leave?",
            "What are the IT priority levels?",
        ]},
        {"group": "Documents & data", "items": [
            "Draft a report on the Q3 shortfall",
            "Explain the Q3 regional sales spreadsheet",
        ]},
        {"group": "Requests", "items": [
            "Raise a ticket - my laptop will not start",
            "Book 3 days of annual leave",
            "Submit my outstanding expense claim",
        ]},
    ],
}
PROMPT_LIBRARY["Study"] = [
    {"group": "Study plan", "items": [
        "Plan my day",
        "What is my AI/ML two-month roadmap?",
        "What is the plan for the JFSD elective?",
        "When do I study and how do I like to learn?",
    ]},
    {"group": "Projects", "items": [
        "What projects are in my portfolio?",
        "What do GSS, HRI and GDI mean?",
        "Draft a report on the MIRAGE project",
    ]},
    {"group": "Mail & diary", "items": [
        "Summarise my inbox",
        "Draft a reply to Anand Rao about the paper draft",
        "Find a 30 minute slot with Anand Rao",
        "Chase the threads waiting on my reply",
    ]},
]
for _dept in ("People", "Finance", "Revenue", "Operations"):
    PROMPT_LIBRARY[_dept] = PROMPT_LIBRARY["_default"]


# ---------------------------------------------------------------------------
# Static front end
# ---------------------------------------------------------------------------
@app.get("/")
def index() -> FileResponse:
    return FileResponse(WEB_DIR / "index.html")


app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")
