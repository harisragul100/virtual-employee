"""The orchestrator: understand the request, pick tools, stage anything risky.

Shape of a run (a ReAct-style loop [5], with the loop bounded by code):

    classify -> read tools -> compose an answer -> stage write actions

Nothing in the write column happens inside a run. Write tools are staged as
pending actions with every field visible and editable, and a person presses
Approve. That is the brief's central design lesson: agents on real office work
still fail often [8, 9], so keep the human on the trigger.
"""
from __future__ import annotations

import re
from collections import Counter
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from . import llm, rag, safety, store, tools
from .config import settings
from .seed import USERS_BY_ID


class Run:
    """One turn. Accumulates a readable trace the UI shows verbatim."""

    def __init__(self, user_id: str, message: str):
        self.id = store.new_id("run")
        self.user_id = user_id
        self.user = USERS_BY_ID.get(user_id, {})
        self.message = message
        self.memory = store.user_memory(user_id)
        self.tone = llm.tone_profile(self.memory.get("tone", ""))
        self.trace: List[Dict] = []
        self.citations: List[Dict] = []
        self.safety_notices: List[Dict] = []
        self.pending_actions: List[Dict] = []
        self.suggestions: List[str] = []
        self.grounding: List[str] = []
        self.started_at = store.now_iso()

    # -- trace helpers ----------------------------------------------------
    def thought(self, text: str) -> None:
        self.trace.append({"step": len(self.trace) + 1, "type": "thought", "text": text})

    def note(self, text: str) -> None:
        self.trace.append({"step": len(self.trace) + 1, "type": "note", "text": text})

    def safety(self, level: str, text: str, detail: str = "") -> None:
        self.trace.append({"step": len(self.trace) + 1, "type": "safety",
                           "text": text, "level": level, "detail": detail})
        self.safety_notices.append({"level": level, "text": text, "detail": detail})

    def use(self, name: str, args: Optional[Dict] = None) -> Dict:
        """Call a read tool and record it."""
        args = args or {}
        spec = tools.REGISTRY[name]
        result = tools.call_read(name, self.user_id, args)
        self.trace.append({
            "step": len(self.trace) + 1,
            "type": "tool",
            "tool": name,
            "tool_title": spec["title"],
            "system": spec["system"],
            "scope": spec["scope"],
            "args": args,
            "observation": _observe(name, result),
            "denied": bool(result.get("_denied")),
        })
        if result.get("_denied"):
            self.safety("blocked", "Permission not delegated", result.get("reason", ""))
        return result

    def stage(self, tool_name: str, args: Dict, summary: str, why: str,
              risk: str = "medium", fields: Optional[List[Dict]] = None) -> Optional[Dict]:
        """Queue a write tool for human approval. Runs DLP first."""
        spec = tools.REGISTRY[tool_name]

        recipients = args.get("to") or args.get("attendees") or []
        content = "\n".join(str(v) for v in args.values() if isinstance(v, str))
        dlp = safety.dlp_check(content, recipients if isinstance(recipients, list) else [],
                               self.user_id, tool_name)
        if not dlp["allowed"]:
            labels = ", ".join(f["label"] for f in dlp["findings"] if f["blocking"])
            self.safety(
                "blocked",
                "Blocked by data-loss prevention: %s" % labels,
                "This content cannot leave in that form. Remove the flagged data, or send it "
                "yourself through the approved channel.",
            )
            return None

        gate = safety.check_scope(self.user_id, spec["scope"], spec["title"])
        if not gate["allowed"]:
            self.safety("blocked", "Permission not delegated", gate["reason"])
            return None

        if not settings.confirm_before_acting:
            # Demo switch only. Shows why the gate exists by removing it.
            result = tools.execute_write(tool_name, self.user_id, args)
            self.note("Confirmation gate is OFF - executed immediately: %s"
                      % result.get("receipt", tool_name))
            return None

        action = {
            "id": store.new_id("act"),
            "run_id": self.id,
            "user": self.user_id,
            "tool": tool_name,
            "tool_title": spec["title"],
            "system": spec["system"],
            "scope": spec["scope"],
            "summary": summary,
            "why": why,
            "risk": risk,
            "args": args,
            "fields": fields or _default_fields(args),
            "dlp_findings": dlp["findings"],
            "status": "pending",
            "created_at": store.now_iso(),
            "edited": False,
        }
        store.staged_actions[action["id"]] = action
        self.pending_actions.append(action)
        self.trace.append({
            "step": len(self.trace) + 1,
            "type": "staged",
            "tool": tool_name,
            "tool_title": spec["title"],
            "system": spec["system"],
            "text": summary,
            "action_id": action["id"],
        })
        store.log("action_staged", self.user_id, tool=tool_name, action_id=action["id"],
                  detail=summary, risk=risk)
        return action

    def ground(self, text: str) -> None:
        self.grounding.append(text)

    def write(self, kind: str, fallback: str) -> str:
        return llm.write(kind, {"tone": self.memory.get("tone", ""),
                                "grounding": "\n\n".join(self.grounding)}, fallback)


def _default_fields(args: Dict) -> List[Dict]:
    fields = []
    for key, value in args.items():
        if key.startswith("_"):
            continue
        if isinstance(value, list) and all(isinstance(v, str) for v in value):
            value = ", ".join(value)
        if not isinstance(value, (str, int, float)):
            continue
        text = str(value)
        fields.append({
            "key": key,
            "label": key.replace("_", " ").capitalize(),
            "value": text,
            "multiline": len(text) > 90 or "\n" in text,
        })
    return fields


def _observe(name: str, result: Dict) -> str:
    """One readable line per tool call, for the trace."""
    if result.get("_denied"):
        return "denied"
    if name == "mail.list":
        flagged = sum(1 for m in result.get("messages", []) if m.get("safety_findings"))
        return "%d message(s) read%s" % (result.get("count", 0),
                                         ", %d flagged" % flagged if flagged else "")
    if name == "mail.get":
        return "opened: %s" % result["message"]["subject"] if result.get("found") else "no match"
    if name == "calendar.list":
        return "%d event(s) in range" % result.get("count", 0)
    if name == "calendar.find_slot":
        return "%d candidate slot(s)" % len(result.get("slots", []))
    if name == "knowledge.search":
        base = "%d passage(s) retrieved" % len(result.get("hits", []))
        if result.get("withheld"):
            base += ", %d withheld by access control" % result["withheld"]
        return base
    if name == "sheets.read":
        return result.get("name", "not found") if result.get("found") else "no access"
    if name == "hr.leave_balance":
        return "%s day(s) remaining" % result.get("remaining", "?")
    if name == "expenses.list_receipts":
        return "%d receipt(s), USD %.2f" % (len(result.get("items", [])), result.get("total", 0))
    if name == "tickets.list":
        return "%d open ticket(s)" % result.get("count", 0)
    if name == "glossary.lookup":
        return "found" if result.get("found") else "not in glossary"
    if name == "tasks.list":
        return "%d task(s)" % len(result.get("tasks", []))
    return "ok"


# ===========================================================================
# Intent handlers
# ===========================================================================
def _h_inbox_triage(run: Run, ents: Dict) -> str:
    run.thought("Read the inbox, screen every message for hidden instructions, then sort by "
                "what needs a decision from %s." % run.user["name"].split()[0])
    data = run.use("mail.list", {"limit": 25})
    msgs = data.get("messages", [])
    if not msgs:
        return "Your inbox is empty."

    flagged = [m for m in msgs if m.get("safety_findings")]
    for m in flagged:
        worst = "critical" if m.get("quarantined") else "warning"
        run.safety(
            worst,
            'Hidden instruction found in "%s"' % m["subject"],
            "From %s. The text tried to: %s. I stripped it before reading the message and I "
            "have not acted on it." % (m["from"], "; ".join(sorted({f["why"] for f in m["safety_findings"]}))),
        )

    safe = [m for m in msgs if not m.get("safety_findings")]
    urgent = [m for m in safe if m["importance"] == "high" and m["unread"]]
    waiting = [m for m in safe if m["awaiting_reply"] and m["waiting_days"] >= 2]
    fyi = [m for m in safe if m not in urgent and m not in waiting]

    lines = ["**Inbox as of %s** - %d messages, %d unread.\n"
             % (llm.stamp(), len(msgs), sum(1 for m in msgs if m["unread"]))]

    if urgent:
        lines.append("### Needs you today")
        for m in urgent:
            lines.append("- **%s** - %s\n  %s" % (_sender(m["from"]), m["subject"], _gist(m["body"])))
        lines.append("")
    if waiting:
        lines.append("### Waiting on your reply")
        for m in sorted(waiting, key=lambda x: -x["waiting_days"]):
            lines.append("- **%s** - %s _(%d day%s)_" % (_sender(m["from"]), m["subject"],
                                                         m["waiting_days"], "s" if m["waiting_days"] != 1 else ""))
        lines.append("")
    if fyi:
        lines.append("### For information")
        for m in fyi[:5]:
            lines.append("- %s - %s" % (_sender(m["from"]), m["subject"]))
        lines.append("")
    if flagged:
        lines.append("### Quarantined")
        for m in flagged:
            lines.append("- **%s** - %s. Hidden text aimed at me was removed; treat the sender "
                         "with caution and report it to security." % (_sender(m["from"]), m["subject"]))
        lines.append("")

    lines.append("_Nothing has been sent or actioned. Ask me to draft any of these replies._")

    run.ground("\n".join("%s | %s | %s" % (m["from"], m["subject"], m["body"][:200]) for m in msgs))
    for m in urgent[:2]:
        run.suggestions.append("Draft a reply to %s about %s" % (_sender(m["from"]), _short(m["subject"])))
    if waiting:
        run.suggestions.append("Chase the threads waiting on my reply")
    return run.write("Summarise an inbox for a busy colleague", "\n".join(lines))


def _h_draft_reply(run: Run, ents: Dict) -> str:
    target = _reference_from(run.message, ents)
    run.thought("Find the message being referred to, check whether it needs a policy answer, "
                "then draft a reply in the saved tone.")
    got = run.use("mail.get", {"reference": target})
    if not got.get("found"):
        run.suggestions.append("Summarise my inbox")
        return ("I could not work out which message you mean. Ask me to summarise your inbox and "
                "then point at one by sender or subject.")

    msg = got["message"]
    if got.get("safety_findings"):
        run.safety(
            "critical",
            "This message contains instructions aimed at me",
            "From %s. It tried to: %s. I am treating the message as information only, and the "
            "draft below answers the human part of it and nothing else."
            % (msg["from"], "; ".join(sorted({f["why"] for f in got["safety_findings"]}))),
        )

    # Does the reply need grounding in policy?
    kn = run.use("knowledge.search", {"query": msg["subject"] + " " + msg["body"][:300]})
    hits = kn.get("hits", [])
    run.citations = rag.sources(hits)
    if hits:
        run.ground("\n".join("%s: %s" % (h["title"], h["snippet"]) for h in hits))

    sender_name = _sender(msg["from"])
    first = sender_name.split()[0]
    sig = run.memory.get("signature", run.user["name"])
    opener = run.tone["opener"]

    body_lines = ["Hi %s," % first, ""]
    if opener:
        body_lines += [opener, ""]

    if got.get("safety_findings"):
        body_lines += [
            "Thanks for the candidate pack - I have it." if "candidate" in msg["subject"].lower()
            else "Thanks for your message.",
            "",
            "I am not able to share reward or salary information outside the People Team, so I "
            "will not be responding to that part. If you need banding guidance for the search, "
            "please raise it with our Reward team through the agreed channel.",
            "",
            "On the candidates: I will review the three profiles and come back with interview "
            "availability by the end of tomorrow.",
        ]
    elif hits:
        # Citation markers belong in the chat preview, not in an e-mail to a
        # colleague - the named source at the end does that job better.
        quoted = re.sub(r"\s*\[\d+\]", "", _policy_answer(hits, msg["body"]))
        body_lines += [
            "Thanks for your note about %s." % _topic(msg["subject"]),
            "",
            quoted,
            "",
            "That comes from our %s, last reviewed %s."
            % (hits[0]["title"], hits[0]["last_reviewed"]),
        ]
    else:
        body_lines += [
            "Thanks for your note about %s." % _topic(msg["subject"]),
            "",
            _acknowledge(msg),
            "",
            "I will come back to you with the detail by end of day tomorrow.",
        ]
    body_lines += ["", "Best regards,", sig]
    body = "\n".join(body_lines)

    body = run.write("Write a reply e-mail in the user's tone", body)

    subject = msg["subject"] if msg["subject"].lower().startswith("re:") else "Re: " + msg["subject"]
    to = [_address(msg["from"])]

    run.stage(
        "mail.send",
        {"to": to, "subject": subject, "body": body, "_in_reply_to": msg["id"]},
        summary="Send a reply to %s" % sender_name,
        why="You asked for a reply to \"%s\"." % msg["subject"],
        risk="high" if msg.get("external") else "medium",
    )

    preview = "**Draft reply to %s**\n\n> %s\n\n" % (sender_name, body.replace("\n", "\n> "))
    preview += ("Read it, edit anything you want in the approval card, then press Approve. "
                "Nothing leaves your mailbox until you do.")
    if hits:
        block = _sources_block(body, hits) or ["**Sources**"] + rag.citation_lines(hits[:1])
        preview += "\n\n" + "\n".join(block)
    return preview


def _h_follow_up(run: Run, ents: Dict) -> str:
    run.thought("Find threads where the other person is waiting on you, oldest first, and draft "
                "a short chaser for each.")
    data = run.use("mail.list", {"limit": 25})
    waiting = sorted([m for m in data.get("messages", []) if m["awaiting_reply"]],
                     key=lambda m: -m["waiting_days"])
    waiting = [m for m in waiting if not m.get("quarantined")]
    if not waiting:
        return "Nothing is waiting on you - every thread has had a reply."

    sig = run.memory.get("signature", run.user["name"])
    lines = ["**%d thread%s waiting on you**\n" % (len(waiting), "s" if len(waiting) != 1 else "")]
    for m in waiting[:3]:
        first = _sender(m["from"]).split()[0]
        body = "\n".join([
            "Hi %s," % first, "",
            "Coming back to you on \"%s\" - apologies for the delay." % _short(m["subject"]),
            "",
            "%s I will have this with you by end of day tomorrow." % _acknowledge(m),
            "", "Best regards,", sig,
        ])
        run.stage(
            "mail.send",
            {"to": [_address(m["from"])], "subject": "Re: " + m["subject"], "body": body,
             "_in_reply_to": m["id"]},
            summary="Reply to %s (waiting %d day%s)" % (_sender(m["from"]), m["waiting_days"],
                                                        "s" if m["waiting_days"] != 1 else ""),
            why="This thread has had no reply from you for %d day(s)." % m["waiting_days"],
            risk="high" if m.get("external") else "medium",
        )
        lines.append("- **%s** - %s _(waiting %d day%s)_"
                     % (_sender(m["from"]), m["subject"], m["waiting_days"],
                        "s" if m["waiting_days"] != 1 else ""))
    lines.append("")
    lines.append("I have drafted a reply for each of the top %d. Approve them one at a time - "
                 "each card is editable." % min(3, len(waiting)))
    return "\n".join(lines)


def _h_find_slot(run: Run, ents: Dict) -> str:
    duration = ents.get("duration_minutes") or _default_duration(run)
    people = ents.get("people") or []
    run.thought("Check your calendar and %s against your working hours."
                % (", ".join(people) + "'s calendar" if people else "your own diary"))
    res = run.use("calendar.find_slot", {"attendees": people, "duration_minutes": duration,
                                         "within_days": 5})
    slots = res.get("slots", [])
    if not slots:
        return ("I could not find a %d-minute gap in the next five working days for %s. Widen the "
                "window or shorten the meeting and I will look again."
                % (duration, ", ".join(people) if people else "you"))
    lines = ["**%d-minute slots** (your working hours %s%s)\n"
             % (duration, res["working_hours"],
                ", checked against " + ", ".join(people) if people else "")]
    for i, s in enumerate(slots, 1):
        lines.append("%d. %s" % (i, s["label"]))
    lines.append("\nSay \"book the first one\" and I will prepare the invite for your approval.")
    run.suggestions.append("Book the first slot with %s" % (", ".join(people) if people else "my team"))
    return "\n".join(lines)


def _h_schedule_meeting(run: Run, ents: Dict) -> str:
    duration = ents.get("duration_minutes") or _default_duration(run)
    people = ents.get("people") or []
    run.thought("Find a slot that works for everyone, then prepare the invite - but leave the "
                "sending to you.")
    res = run.use("calendar.find_slot", {"attendees": people, "duration_minutes": duration,
                                         "within_days": 5})
    slots = res.get("slots", [])
    if not slots:
        return "No %d-minute slot is free in the next five working days. Shall I look further out?" % duration

    chosen = slots[0]
    title = _meeting_title(run.message, people)
    notes = "Prepared by Aide at %s from: \"%s\"" % (llm.stamp(), run.message.strip())

    run.stage(
        "calendar.create_event",
        {"title": title, "start": chosen["start"], "end": chosen["end"],
         "attendees": people or [run.user["name"]], "notes": notes},
        summary="Book \"%s\" on %s" % (title, chosen["label"]),
        why="First slot where everyone is free inside your working hours.",
        risk="medium",
    )

    lines = ["I have prepared the invite - **nothing is booked yet**.\n",
             "- **What:** %s" % title,
             "- **When:** %s" % chosen["label"],
             "- **Who:** %s" % (", ".join(people) if people else "you"),
             "- **Length:** %d minutes" % duration, ""]
    if len(slots) > 1:
        lines.append("Alternatives if that does not suit: " + "; ".join(s["label"] for s in slots[1:3]))
    lines.append("\nCheck the card and press Approve to send the invites.")
    return "\n".join(lines)


def _h_meeting_brief(run: Run, ents: Dict) -> str:
    run.thought("Find the next relevant meeting, pull the related mail and any policy it touches, "
                "and write a one-page brief.")
    cal = run.use("calendar.list", {"days": 7})
    events = cal.get("events", [])
    if not events:
        return "You have nothing in the diary for the next seven days."

    target = events[0]
    if ents.get("people"):
        for e in events:
            if any(p.split()[0] in " ".join(e.get("attendees", [])) for p in ents["people"]):
                target = e
                break

    mail_data = run.use("mail.list", {"limit": 25})
    keywords = set(w.lower() for w in target["title"].split() if len(w) > 3)
    related = [m for m in mail_data.get("messages", [])
               if keywords.intersection(set(m["subject"].lower().split())) or
               any(a.split()[0] in m["from"] for a in target.get("attendees", []))]

    kn = run.use("knowledge.search", {"query": target["title"]})
    run.citations = rag.sources(kn.get("hits", []))

    when = datetime.fromisoformat(target["start"]).strftime("%a %d %b, %H:%M")
    lines = ["# Brief: %s" % target["title"], "",
             "**When:** %s  |  **Attendees:** %s" % (when, ", ".join(target.get("attendees", [])) or "you"), "",
             "## Why it matters"]
    lines.append("- %s" % (("This is the first item in your diary and the attendees include %s."
                            % ", ".join(target.get("attendees", [])[:3])) if target.get("attendees")
                           else "A working block you set aside."))
    if related:
        lines += ["", "## Recent context from your mail"]
        for m in related[:4]:
            lines.append("- **%s** - %s: %s" % (_sender(m["from"]), _short(m["subject"]), _gist(m["body"])))
    if kn.get("hits"):
        lines += ["", "## Policy that may come up"]
        for i, h in enumerate(kn["hits"][:2], 1):
            lines.append("- %s [%d]" % (_first_sentence(h["snippet"]), i))
    lines += ["", "## Suggested questions to ask",
              "- What decision do we need out of this session?",
              "- Who owns the follow-up and by when?",
              "- What would make us change course?"]
    if kn.get("hits"):
        lines += ["", "**Sources**"] + rag.citation_lines(kn["hits"][:2])

    body = run.write("Write a short meeting brief", "\n".join(lines))
    run.stage("docs.create", {"title": "Brief - %s" % target["title"], "body": body,
                              "format": "meeting brief"},
              summary="Save this brief to your workspace",
              why="So you can open it from your documents before the meeting.",
              risk="low")
    run.suggestions.append("Turn this brief into tasks")
    return body


def _h_draft_document(run: Run, ents: Dict) -> str:
    run.thought("Work out the document type and audience, ground it in any relevant policy, "
                "then write a complete first draft.")
    kn = run.use("knowledge.search", {"query": run.message})
    hits = kn.get("hits", [])
    run.citations = rag.sources(hits)
    if hits:
        run.ground("\n".join("%s: %s" % (h["title"], h["snippet"]) for h in hits))

    kind, title = _document_kind(run.message)
    today = datetime.now().strftime("%d %B %Y")

    if kind == "slides":
        body = "\n".join([
            "# %s" % title, "",
            "_Outline deck - %s - %s_" % (run.user["name"], today), "",
            "## Slide 1 - Title", "%s" % title, "%s, %s" % (run.user["role"], today), "",
            "## Slide 2 - The situation", "- Where we are today",
            "- What has changed since the last review", "- Why it needs a decision now", "",
            "## Slide 3 - What we found", "- Finding one, with the number that supports it",
            "- Finding two", "- Finding three", "",
            "## Slide 4 - Options", "- Option A - fastest, lowest change",
            "- Option B - balanced", "- Option C - most thorough, slowest", "",
            "## Slide 5 - Recommendation", "- The option we propose and why",
            "- What it costs and who needs to approve it", "",
            "## Slide 6 - Next steps", "- Owner, action and date for each of the first three steps",
        ])
    elif kind == "memo":
        body = "\n".join([
            "# %s" % title, "",
            "**To:** %s  |  **From:** %s  |  **Date:** %s"
            % (run.memory.get("frequent_contacts", "Team").split("(")[0].strip(), run.user["name"], today), "",
            "## Purpose", "This note sets out %s and what I need from you." % title.lower(), "",
            "## Background", "Summarise in three or four lines what prompted this.", "",
            "## What I propose", "1. The change or decision.", "2. Who it affects.",
            "3. When it would take effect.", "",
            "## What I need", "A yes or no by [date]. If you would like changes, mark them "
            "directly on this note.",
        ])
    else:
        body = "\n".join([
            "# %s" % title, "",
            "_Prepared by %s, %s - first draft_" % (run.user["name"], today), "",
            "## Summary", "Three lines a busy reader can act on without reading further.", "",
            "## Background", "What prompted this piece of work and what has changed.", "",
            "## Findings", "1. The first thing worth knowing, with the evidence behind it.",
            "2. The second.", "3. The third.", "",
            "## Recommendation", "What we should do, what it costs, and who has to approve it.", "",
            "## Next steps", "| Action | Owner | By when |", "| --- | --- | --- |",
            "| Confirm the approach | %s | +3 days |" % run.user["name"].split()[0],
            "| Circulate for comment | | +7 days |", "| Final version | | +14 days |",
        ])

    if hits:
        body += "\n\n## Relevant company policy\n"
        for i, h in enumerate(hits[:2], 1):
            body += "- %s [%d]\n" % (_first_sentence(h["snippet"]), i)
        body += "\n**Sources**\n" + "\n".join(rag.citation_lines(hits[:2]))

    body = run.write("Write a first draft %s" % kind, body)

    run.stage("docs.create", {"title": title, "body": body, "format": kind},
              summary="Save \"%s\" to your workspace" % title,
              why="You asked for a first draft.", risk="low")
    run.suggestions.append("Rewrite this for a non-specialist audience")
    return (body + "\n\n---\n_First draft - the placeholders in square brackets are yours to fill. "
            "Approve the card to save it._")


def _h_summarise_document(run: Run, ents: Dict) -> str:
    query = ents["quoted"][0] if ents.get("quoted") else run.message
    run.thought("Retrieve the document from approved company content and summarise only what it "
                "actually says.")
    kn = run.use("knowledge.search", {"query": query})
    hits = kn.get("hits", [])
    run.citations = rag.sources(hits)
    if not hits:
        return _no_hits(kn, run)
    grouped: Dict[str, List[Dict]] = {}
    for h in hits:
        grouped.setdefault(h["title"], []).append(h)
    lines = []
    for title, group in grouped.items():
        g0 = group[0]
        lines.append("### %s" % title)
        lines.append("_Owner: %s  |  last reviewed %s%s_"
                     % (g0["owner"], g0["last_reviewed"], "  |  **review overdue**" if g0["stale"] else ""))
        for h in group:
            for sent in _sentences(h["snippet"])[:3]:
                lines.append("- %s" % sent)
        lines.append("")
    lines.append("**Sources**")
    lines += rag.citation_lines(hits)
    run.ground("\n".join(h["snippet"] for h in hits))
    return run.write("Summarise the retrieved policy passages", "\n".join(lines))


def _h_spreadsheet_explain(run: Run, ents: Dict) -> str:
    run.thought("Open the sheet, compute the totals and the month-on-month movement, then explain "
                "it in words rather than formulas.")
    data = run.use("sheets.read", {"name": "q3-regional-sales"})
    if not data.get("found"):
        return data.get("reason", "I could not open that spreadsheet.")

    rows = sorted(data["analysis"], key=lambda a: a["trend_pct"])
    worst, best = rows[0], rows[-1]
    lines = ["**%s** - owned by %s\n" % (data["name"], data["owner"]),
             "Quarter total **USD %s** against a target of **USD %s** - that is **%.1f%% of target**.\n"
             % (_money(data["total"]), _money(data["target"]), data["attainment_pct"]),
             "| Region | Jul | Aug | Sep | Q3 total | vs target | Jul to Sep |",
             "| --- | ---: | ---: | ---: | ---: | ---: | ---: |"]
    for a in data["analysis"]:
        m = a["monthly"]
        lines.append("| %s | %s | %s | %s | %s | %.0f%% | %+.1f%% |"
                     % (a["region"], _money(m["Jul"]), _money(m["Aug"]), _money(m["Sep"]),
                        _money(a["total"]), a["attainment_pct"], a["trend_pct"]))
    lines += ["", "**What stands out**",
              "- **%s is the problem.** It fell %.1f%% between July and September and finished at "
              "%.0f%% of target - the single biggest gap in the quarter."
              % (worst["region"], abs(worst["trend_pct"]), worst["attainment_pct"]),
              "- **%s is the bright spot**, up %.1f%% over the quarter and %.0f%% of target."
              % (best["region"], best["trend_pct"], best["attainment_pct"]),
              "- Three of four regions finished below target, so this is not one region's story alone.",
              "", "**Formulas if you want to rebuild this**",
              "- Q3 total: `=SUM(B2:D2)`",
              "- Attainment: `=SUM(B2:D2)/E2` formatted as a percentage",
              "- Jul to Sep movement: `=(D2-B2)/B2`",
              "", "_Figures come straight from the sheet; I have not adjusted anything._"]
    run.ground("\n".join(lines))
    run.suggestions.append("Draft a note to my manager about the %s shortfall" % worst["region"])
    return run.write("Explain a spreadsheet to a non-financial reader", "\n".join(lines))


def _h_raise_ticket(run: Run, ents: Dict) -> str:
    run.thought("Check the IT standard for the right priority, then fill the ticket in for you.")
    kn = run.use("knowledge.search", {"query": "IT ticket priority definitions response times"})
    run.citations = rag.sources(kn.get("hits", []))

    text = run.message.lower()
    if any(w in text for w in ("cannot work", "can't work", "dead", "won't start", "wont start",
                               "no laptop", "outage", "locked out")):
        priority, reason = "P2", "you cannot work until it is fixed"
    elif ents.get("urgent"):
        priority, reason = "P2", "you flagged it as urgent"
    elif any(w in text for w in ("access", "request", "please add", "new ")):
        priority, reason = "P4", "this is a request rather than a fault"
    else:
        priority, reason = "P3", "it is degraded but you can still work"

    title = _ticket_title(run.message)
    description = ("Reported by %s (%s).\n\nIn their words: \"%s\"\n\nRaised through Aide at %s."
                   % (run.user["name"], run.user["role"], run.message.strip(), llm.stamp()))

    run.stage("tickets.create",
              {"title": title, "description": description, "priority": priority,
               "category": "End-user computing"},
              summary="Raise %s ticket: %s" % (priority, title),
              why="Priority %s because %s." % (priority, reason), risk="low")

    lines = ["I have filled in the ticket - **not submitted yet**.\n",
             "- **Title:** %s" % title, "- **Priority:** %s - %s" % (priority, reason),
             "- **Category:** End-user computing", ""]
    if kn.get("hits"):
        lines.append("Priority definitions come from *%s* [1]." % kn["hits"][0]["title"])
        lines += ["", "**Sources**"] + rag.citation_lines(kn["hits"][:1])
    lines.append("\nEdit anything in the card, then Approve to send it to the Service Desk.")
    return "\n".join(lines)


def _h_leave_request(run: Run, ents: Dict) -> str:
    run.thought("Check the balance first, then the notice rules, then prepare the request.")
    bal = run.use("hr.leave_balance", {})
    kn = run.use("knowledge.search", {"query": "annual leave entitlement notice carry over"})
    run.citations = rag.sources(kn.get("hits", []))

    days = ents.get("days")
    asking_balance = bool(re.search(r"\b(balance|how (much|many)|left|remaining)\b",
                                    run.message, re.I))

    header = ("**Your leave**: %s days entitlement + %s carried over, %s taken, %s already booked "
              "-> **%s days left**." % (bal.get("entitlement"), bal.get("carried_over"),
                                        bal.get("taken"), bal.get("booked"), bal.get("remaining")))
    if asking_balance and not days:
        out = [header, ""]
        if kn.get("hits"):
            out += ["Carry-over rule: %s" % _find_sentence(kn["hits"], "carry"), "",
                    "**Sources**"] + rag.citation_lines(kn["hits"][:2])
        run.suggestions.append("Book 3 days off next month")
        return "\n".join(out)

    days = days or 1
    if days > (bal.get("remaining") or 0):
        return (header + "\n\nThat request is %d day(s) more than you have left. Reduce it, or "
                "speak to %s about an exception." % (days - bal.get("remaining", 0),
                                                     run.user.get("manager", "your manager")))

    start = (datetime.now() + timedelta(days=21)).date()
    end = start + timedelta(days=days - 1)
    notice_days = 15 if days >= 5 else 5
    notice_ok = 21 >= notice_days

    run.stage("hr.request_leave",
              {"start_date": start.isoformat(), "end_date": end.isoformat(), "days": days,
               "note": "Requested through Aide at %s" % llm.stamp()},
              summary="Request %d day(s) leave, %s to %s" % (days, start, end),
              why="Goes to %s for approval. Dates are a placeholder - edit them in the card."
                  % run.user.get("manager", "your manager"),
              risk="medium")

    lines = [header, "",
             "I have prepared a request for **%d day(s), %s to %s**." % (days, start, end),
             "- Notice required for %d day(s): %d working days. You are giving 21 - %s."
             % (days, notice_days, "fine" if notice_ok else "short"),
             "- Approver: %s" % run.user.get("manager", "your manager"), ""]
    if kn.get("hits"):
        lines += ["**Sources**"] + rag.citation_lines(kn["hits"][:2])
    lines.append("\nChange the dates in the card if they are wrong, then Approve.")
    return "\n".join(lines)


def _h_expense_claim(run: Run, ents: Dict) -> str:
    run.thought("Pull the unclaimed receipts, check each one against the travel policy caps, "
                "then build the claim.")
    rec = run.use("expenses.list_receipts", {})
    items = rec.get("items", [])
    if not items:
        return "You have no unclaimed receipts waiting."

    kn = run.use("knowledge.search", {"query": "travel expense accommodation cap per diem claim deadline"})
    run.citations = rag.sources(kn.get("hits", []))

    flags = []
    for it in items:
        if it["category"] == "Accommodation" and it["amount"] / 3 > 220:
            flags.append("%s averages USD %.0f a night, above the USD 220 tier-1 cap - add a "
                         "reason or split it." % (it["description"], it["amount"] / 3))
        if it["category"] == "Meals" and it["amount"] > 65:
            flags.append("%s is USD %.2f, over the USD 65 daily meal rate - mark it as client "
                         "entertainment and name the guests." % (it["description"], it["amount"]))

    total = rec["total"]
    run.stage("expenses.submit_claim",
              {"items": items, "total": total,
               "purpose": "Business travel - receipts captured from the travel desk and your mail"},
              summary="Submit expense claim for USD %.2f (%d items)" % (total, len(items)),
              why="Goes to %s for approval." % run.user.get("manager", "your manager"),
              risk="medium")

    lines = ["**Claim ready - USD %.2f across %d receipts**\n" % (total, len(items)),
             "| Date | Description | Category | Amount |", "| --- | --- | --- | ---: |"]
    for it in items:
        lines.append("| %s | %s | %s | %.2f |" % (it["date"], it["description"], it["category"], it["amount"]))
    if flags:
        lines += ["", "**Check these before you approve**"] + ["- %s" % f for f in flags]
    if kn.get("hits"):
        lines += ["", "Claims must be submitted within 30 days of return (*%s*) [1]." % kn["hits"][0]["title"],
                  "", "**Sources**"] + rag.citation_lines(kn["hits"][:2])
    lines.append("\nNothing is submitted until you approve the card.")
    return "\n".join(lines)


def _h_create_tasks(run: Run, ents: Dict) -> str:
    run.thought("Turn what you said - plus anything still open in your mail - into concrete, "
                "owned actions.")
    items: List[str] = []
    for q in ents.get("quoted", []):
        items.append(q)
    if not items:
        data = run.use("mail.list", {"limit": 10})
        for m in data.get("messages", []):
            if m["awaiting_reply"] and not m.get("quarantined"):
                items.append("Reply to %s about %s" % (_sender(m["from"]), _short(m["subject"], 50)))
        cal = run.use("calendar.list", {"days": 3})
        for e in cal.get("events", [])[:2]:
            items.append("Prepare for %s" % e["title"])
    items = items[:6] or ["Follow up on today's requests"]

    due = (datetime.now() + timedelta(days=2)).date().isoformat()
    run.stage("tasks.create", {"items": items, "due": due},
              summary="Add %d task(s) to your list" % len(items),
              why="Drawn from your mail and diary.", risk="low")
    return "\n".join(["**%d task(s) ready to add** (due %s)\n" % (len(items), due)] +
                     ["- [ ] %s" % i for i in items] +
                     ["", "Approve the card to add them, or edit the list first."])


def _h_daily_plan(run: Run, ents: Dict) -> str:
    run.thought("Combine the diary, the inbox and your open tasks into one ordered plan for today.")
    cal = run.use("calendar.list", {"days": 1})
    mail_data = run.use("mail.list", {"limit": 25})
    task_data = run.use("tasks.list", {})

    events = cal.get("events", [])
    msgs = mail_data.get("messages", [])
    urgent = [m for m in msgs if m["importance"] == "high" and m["unread"]]
    overdue = sorted([m for m in msgs if m["awaiting_reply"]], key=lambda m: -m["waiting_days"])[:3]
    flagged = [m for m in msgs if m.get("safety_findings")]

    free = 0
    hours = tools._working_hours(run.memory.get("working_hours", "09:00-17:00"))
    span = (hours[1] - hours[0]) * 60
    booked = sum((datetime.fromisoformat(e["end"]) - datetime.fromisoformat(e["start"])).seconds // 60
                 for e in events)
    free = max(0, span - booked)

    lines = ["# Your day - %s" % datetime.now().strftime("%A %d %B"), "",
             "**%d meeting(s)**, about **%d hour(s) %d minutes** of unbooked time.\n"
             % (len(events), free // 60, free % 60)]
    if events:
        lines.append("## In the diary")
        for e in events:
            lines.append("- **%s** - %s" % (datetime.fromisoformat(e["start"]).strftime("%H:%M"), e["title"]))
        lines.append("")
    lines.append("## Do these first")
    n = 1
    for m in urgent[:2]:
        lines.append("%d. **%s** - %s. %s" % (n, _sender(m["from"]), _short(m["subject"], 60), _gist(m["body"])))
        n += 1
    for m in overdue[:2]:
        if m in urgent:
            continue
        lines.append("%d. Reply to **%s** - waiting %d day(s) on \"%s\"."
                     % (n, _sender(m["from"]), m["waiting_days"], _short(m["subject"], 50)))
        n += 1
    if n == 1:
        lines.append("1. Nothing is urgent. Use the quiet run for the work you keep postponing.")
    if task_data.get("tasks"):
        lines += ["", "## On your list"]
        for t in task_data["tasks"][:5]:
            lines.append("- [%s] %s" % ("x" if t["done"] else " ", t["title"]))
    if flagged:
        lines += ["", "## One thing to be careful of",
                  "- \"%s\" from %s contained hidden instructions aimed at me. I ignored them; "
                  "please report the sender." % (flagged[0]["subject"], _sender(flagged[0]["from"]))]
    run.suggestions.append("Turn this plan into tasks")
    return run.write("Write a short daily plan", "\n".join(lines))


def _h_explain_jargon(run: Run, ents: Dict) -> str:
    term = ents.get("acronym") or (ents["quoted"][0] if ents.get("quoted") else run.message.split()[-1])
    run.thought("Check the company glossary first; fall back to the wider document set.")
    res = run.use("glossary.lookup", {"term": term})
    if res.get("found"):
        out = ["**%s** - %s" % (res["term"], res["definition"])]
        kn = run.use("knowledge.search", {"query": res["term"] + " " + res["definition"]})
        if kn.get("hits"):
            run.citations = rag.sources(kn["hits"][:1])
            out += ["", "Seen in: *%s*." % kn["hits"][0]["title"]]
        return "\n".join(out)
    kn = run.use("knowledge.search", {"query": term})
    if kn.get("hits"):
        run.citations = kn["hits"]
        return ("\"%s\" is not in the glossary, but it appears here:\n\n- %s\n\n**Sources**\n%s"
                % (term, _first_sentence(kn["hits"][0]["snippet"]), "\n".join(rag.citation_lines(kn["hits"][:2]))))
    return ("\"%s\" is not in the company glossary and I could not find it in the documents you "
            "have access to. Known terms: %s." % (term, ", ".join(t.upper() for t in res.get("known_terms", [])[:12])))


def _h_knowledge_qa(run: Run, ents: Dict) -> str:
    run.thought("Search approved company documents - only the ones your account can open - and "
                "answer from those, with sources.")
    kn = run.use("knowledge.search", {"query": run.message})
    hits = kn.get("hits", [])
    run.citations = rag.sources(hits)
    if not hits:
        return _no_hits(kn, run)

    run.ground("\n".join("%s: %s" % (h["title"], h["snippet"]) for h in hits))
    answer = _policy_answer(hits, run.message)
    run.citations = _cited_sources(answer, hits)

    lines = [answer, ""]
    stale = [c for c in run.citations if c["stale"]]
    if stale:
        lines.append("_Note: %s was last reviewed %s, so check it is still current._"
                     % (stale[0]["title"], stale[0]["last_reviewed"]))
        lines.append("")
    if kn.get("withheld"):
        lines.append("_%d other document(s) matched but sit outside your access groups, so I have "
                     "not used them._" % kn["withheld"])
        lines.append("")
    lines += _sources_block(answer, hits)
    return run.write("Answer a policy question from retrieved passages", "\n".join(lines))


def _h_smalltalk(run: Run, ents: Dict) -> str:
    name = run.user["name"].split()[0]
    run.suggestions += ["Summarise my inbox", "What is our travel policy for international trips?",
                        "Plan my day"]
    return "\n".join([
        "Hello %s. I am Aide, your work assistant.\n" % name,
        "I can do these for you, and I show my working every time:",
        "",
        "- **Mail** - summarise the inbox, draft replies in your tone, chase unanswered threads",
        "- **Diary** - find slots, book meetings, prepare briefings",
        "- **Company questions** - answer from our policies with links to the source",
        "- **Documents** - first drafts of reports, memos and decks",
        "- **Spreadsheets** - explain what the numbers are doing",
        "- **Requests** - IT tickets, leave, expenses, to-do items",
        "",
        "Two rules I always keep: I never send, book, submit or delete anything without your "
        "approval, and I only touch what your own account can reach.",
    ])


def _h_unsupported(run: Run, ents: Dict) -> str:
    run.thought("No supported task matched. Say so rather than guess.")
    run.suggestions += ["Summarise my inbox", "Plan my day"]
    return ("I am not sure what you would like me to do, and I would rather ask than guess.\n\n"
            "Try one of the buttons above, or rephrase - for example \"draft a reply to Ayesha\", "
            "\"what is our carry-over rule for leave?\" or \"raise a ticket, my monitor is dead\".")


HANDLERS = {
    "inbox_triage": _h_inbox_triage,
    "draft_reply": _h_draft_reply,
    "follow_up": _h_follow_up,
    "find_slot": _h_find_slot,
    "schedule_meeting": _h_schedule_meeting,
    "meeting_brief": _h_meeting_brief,
    "draft_document": _h_draft_document,
    "summarise_document": _h_summarise_document,
    "spreadsheet_explain": _h_spreadsheet_explain,
    "raise_ticket": _h_raise_ticket,
    "leave_request": _h_leave_request,
    "expense_claim": _h_expense_claim,
    "create_tasks": _h_create_tasks,
    "daily_plan": _h_daily_plan,
    "explain_jargon": _h_explain_jargon,
    "knowledge_qa": _h_knowledge_qa,
    "smalltalk": _h_smalltalk,
    "unsupported": _h_unsupported,
}


# ===========================================================================
# Entry point
# ===========================================================================
def handle(user_id: str, message: str) -> Dict:
    run = Run(user_id, message)
    store.log("request", user_id, detail=message[:160])

    # The user's own message is trusted input, but scan it anyway: it may have
    # been pasted out of an e-mail or a document.
    self_scan = safety.scan_untrusted(message, "user_message", user_id, run.id)
    if self_scan["findings"]:
        run.safety("warning", "Your message contains text that looks like an instruction to me",
                   "Probably pasted from somewhere else. I have ignored that part: %s"
                   % "; ".join(sorted({f["why"] for f in self_scan["findings"]})))

    routing = llm.classify_intent(self_scan["clean_text"])
    intent = routing["intent"]
    entities = llm.extract_entities(self_scan["clean_text"])

    run.trace.append({
        "step": 0, "type": "routing", "intent": intent,
        "intent_label": llm.FRIENDLY_NAMES.get(intent, intent),
        "confidence": routing["confidence"], "reason": routing["reason"],
        "runner_up": routing["runner_up"],
    })

    if routing["confidence"] < 0.45 and intent not in ("knowledge_qa", "unsupported", "smalltalk"):
        run.note("Low confidence (%.0f%%) - I will do the read-only part and check with you before "
                 "anything else." % (routing["confidence"] * 100))

    try:
        answer = HANDLERS[intent](run, entities)
    except Exception as exc:                      # a demo should fail visibly, not silently
        store.log("error", user_id, detail="%s: %s" % (type(exc).__name__, exc))
        answer = ("Something went wrong on my side while handling that (%s). Nothing was sent or "
                  "changed." % type(exc).__name__)
        run.safety("warning", "The run did not finish", str(exc))

    record = {
        "id": run.id,
        "user": user_id,
        "message": message,
        "started_at": run.started_at,
        "finished_at": store.now_iso(),
        "intent": intent,
        "intent_label": llm.FRIENDLY_NAMES.get(intent, intent),
        "confidence": routing["confidence"],
        "engine": llm.engine_label(),
        "answer": answer,
        "trace": run.trace,
        "citations": run.citations,
        "safety_notices": run.safety_notices,
        "pending_actions": [_public_action(a) for a in run.pending_actions],
        "suggestions": run.suggestions[:3],
        "useful": True,
        "baseline_minutes": store.BASELINE_MINUTES.get(intent, 10),
    }
    store.runs[run.id] = record
    return record


def _public_action(a: Dict) -> Dict:
    return {k: v for k, v in a.items() if k != "fn"}


# ---------------------------------------------------------------------------
# Approval / rejection
# ---------------------------------------------------------------------------
def approve(action_id: str, edits: Optional[Dict] = None) -> Dict:
    action = store.staged_actions.get(action_id)
    if not action:
        return {"ok": False, "error": "No such action."}
    if action["status"] != "pending":
        return {"ok": False, "error": "This action was already %s." % action["status"]}

    args = dict(action["args"])
    if edits:
        for key, value in edits.items():
            if key not in args:
                continue
            if isinstance(args[key], list) and isinstance(value, str):
                args[key] = [v.strip() for v in value.split(",") if v.strip()]
            elif isinstance(args[key], int) and not isinstance(args[key], bool):
                try:
                    args[key] = int(value)
                except (TypeError, ValueError):
                    pass
            else:
                args[key] = value
        if args != action["args"]:
            action["edited"] = True
            store.log("action_edited", action["user"], action_id=action_id,
                      detail="User changed the draft before approving.")

    # Re-run DLP against the *edited* content - the person may have pasted
    # something restricted into the box.
    recipients = args.get("to") or args.get("attendees") or []
    content = "\n".join(str(v) for v in args.values() if isinstance(v, str))
    dlp = safety.dlp_check(content, recipients if isinstance(recipients, list) else [],
                           action["user"], action["tool"])
    if not dlp["allowed"]:
        # safety.dlp_check has already written the audit entry.
        labels = ", ".join(f["label"] for f in dlp["findings"] if f["blocking"])
        return {"ok": False,
                "error": "Blocked by data-loss prevention: %s. Remove it and try again." % labels}

    result = tools.execute_write(action["tool"], action["user"], args)
    if result.get("_denied"):
        return {"ok": False, "error": result["reason"]}

    action["status"] = "approved"
    action["args"] = args
    action["executed_at"] = store.now_iso()
    action["result"] = result
    store.log("action_approved", action["user"], action_id=action_id, tool=action["tool"],
              detail=result.get("receipt", ""))
    return {"ok": True, "action": _public_action(action), "receipt": result.get("receipt", "Done.")}


def reject(action_id: str, reason: str = "") -> Dict:
    action = store.staged_actions.get(action_id)
    if not action:
        return {"ok": False, "error": "No such action."}
    if action["status"] != "pending":
        return {"ok": False, "error": "This action was already %s." % action["status"]}
    action["status"] = "rejected"
    action["reason"] = reason
    action["decided_at"] = store.now_iso()
    store.log("action_rejected", action["user"], action_id=action_id, tool=action["tool"],
              detail=reason or "No reason given.")
    return {"ok": True, "action": _public_action(action)}


# ---------------------------------------------------------------------------
# Small text helpers
# ---------------------------------------------------------------------------
def _reference_from(message: str, ents: Dict) -> str:
    """Turn "draft a reply to the recruitment inbox about the pack" into a
    lookup key the mailbox can match on."""
    text = re.sub(
        r"^\s*(please\s+)?(draft|write|prepare|compose|send|do)?\s*(me\s+)?(a|an|the)?\s*"
        r"(quick\s+)?(reply|response|answer|e-?mail)?\s*(back\s+)?(to|for)?\s*",
        "", message.strip(), flags=re.I)
    text = re.sub(r"\b(about|regarding|concerning|re)\b", " ", text, flags=re.I)
    if ents.get("people"):
        text = " ".join(ents["people"]) + " " + text
    return " ".join(text.split()) or message


def _ticket_title(message: str) -> str:
    """Strip the instruction wrapper so the ticket reads like a fault report."""
    t = re.sub(r"^\s*(please\s+)?(raise|open|log|create|submit|file)\b[^-:,]*[-:,]?\s*",
               "", message.strip(), flags=re.I)
    t = re.sub(r"^(a|an|the)\s+(ticket|incident|request|case)\b[\s\-:,]*", "", t, flags=re.I)
    t = t.strip(" -:,.")
    if not t:
        return "IT request"
    return _short(t[:1].upper() + t[1:], 70)


def _sender(addr: str) -> str:
    return addr.split("<")[0].strip().strip('"') or addr


def _address(addr: str) -> str:
    if "<" in addr and ">" in addr:
        return addr.split("<", 1)[1].split(">", 1)[0].strip()
    return addr.strip()


def _topic(subject: str) -> str:
    """Turn a subject line into something that reads inside a sentence."""
    t = re.sub(r"^\s*(re|fw|fwd)\s*:\s*", "", subject or "", flags=re.I)
    t = re.sub(r"^\s*(urgent|action required|important)\s*[:\-]\s*", "", t, flags=re.I)
    t = re.sub(r"^\s*(a\s+)?(question|query|enquiry|note)\s+(about|on|regarding)\s+", "", t, flags=re.I)
    return _short(t.strip(), 60).lower() or "your message"


def _short(text: str, n: int = 48) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= n else text[: n - 1].rstrip() + "..."


def _sentences(text: str) -> List[str]:
    return rag.split_sentences(text)


def _first_sentence(text: str) -> str:
    s = _sentences(text)
    return s[0] if s else text


def _gist(body: str) -> str:
    s = _sentences(body)
    return _short(s[0] if s else body, 120)


def _acknowledge(msg: Dict) -> str:
    body = msg.get("body", "").lower()
    if "?" in msg.get("body", ""):
        return "I have read your question and I am looking into it."
    if any(w in body for w in ("need", "require", "please send", "can you")):
        return "Noted - I am picking this up now."
    return "Thanks for flagging it."


def _policy_answer(hits: List[Dict], question: str) -> str:
    """Quote the sentences that actually answer the question, each cited.

    Extractive on purpose: for a policy question, a sentence lifted verbatim
    from the approved document with a reference is worth more to the reader
    than a fluent paraphrase they then have to verify.
    """
    index = rag.source_index(hits)
    q_words = set(rag._tokenise(question))
    scored = []
    for h in hits:
        for sent in _sentences(h["snippet"]):
            if len(sent.split()) < 5:          # a heading fragment, not an answer
                continue
            terms = set(rag._tokenise(sent))
            # Weight by inverse document frequency, counting each question term
            # once. What matters is *which* parts of the question a sentence
            # addresses - a sentence that says "leave" three times has not
            # answered three times as much of it. And "carry-over" tells us far
            # more than "leave" does, because "leave" is everywhere here.
            weight = sum(rag.idf(t) for t in q_words if t in terms)
            if weight <= 0:
                continue
            # Scale by how relevant the passage was, squared, so a stray
            # sentence in a weakly matching document cannot outrank the body
            # of the document retrieval actually chose.
            weight *= h.get("score", 1.0) ** 2
            scored.append((weight / max(3.0, len(terms) ** 0.5), index[h["doc_id"]], sent))
    scored.sort(key=lambda t: -t[0])

    # Keep only sentences close to the best one. A weak fourth bullet quoted
    # from an unrelated policy reads as padding and costs the reader trust.
    cutoff = scored[0][0] * 0.4 if scored else 0.0
    picked, seen = [], set()
    for weight, idx, sent in scored:
        if weight < cutoff:
            break
        key = sent[:40].lower()
        if key in seen:
            continue
        seen.add(key)
        picked.append("- %s [%d]" % (sent.rstrip(), idx))
        if len(picked) >= 4:
            break
    if not picked:
        best = hits[0]
        picked = ["- %s [%d]" % (_first_sentence(best["snippet"]), index[best["doc_id"]])]
    return "\n".join(picked)


def _sources_block(answer: str, hits: List[Dict]) -> List[str]:
    """Render only the sources the answer actually cites.

    Listing a document nobody quoted invites the reader to go and check a
    reference that was never used, which is worse than listing nothing.
    """
    used = set(int(n) for n in re.findall(r"\[(\d+)\]", answer))
    lines = [ln for ln in rag.citation_lines(hits)
             if int(ln.split("]")[0].lstrip("[")) in used]
    return (["**Sources**"] + lines) if lines else []


def _cited_sources(answer: str, hits: List[Dict]) -> List[Dict]:
    used = set(int(n) for n in re.findall(r"\[(\d+)\]", answer))
    return [s for s in rag.sources(hits) if s["index"] in used]


def _find_sentence(hits: List[Dict], keyword: str) -> str:
    for h in hits:
        for s in _sentences(h["snippet"]):
            if keyword.lower() in s.lower():
                return s
    return _first_sentence(hits[0]["snippet"]) if hits else ""


def _no_hits(kn: Dict, run: Run) -> str:
    msg = ["I could not find an answer in the company documents you have access to.\n"]
    if kn.get("weak"):
        run.note("Retrieval was too weak to answer from (%.0f%% of the question covered by the "
                 "best passage). Declining rather than padding with a loosely related policy."
                 % (kn.get("coverage", 0) * 100))
    if kn.get("withheld"):
        msg.append("%d document(s) matched your question but sit outside your access groups. "
                   "I will not summarise something you cannot open yourself - ask the owning team "
                   "if you need it.\n" % kn["withheld"])
        run.safety("info", "Relevant content withheld by access control",
                   "The assistant only ever reads what your own account can read.")
    msg.append("I would rather say that than invent an answer. Try different words, or ask the "
               "owning team directly.")
    run.suggestions.append("What documents can I search?")
    return "\n".join(msg)


def _default_duration(run: Run) -> int:
    m = re.search(r"(\d+)\s*min", run.memory.get("meeting_length", ""), re.I)
    return int(m.group(1)) if m else 30


def _meeting_title(message: str, people: List[str]) -> str:
    m = re.search(r"\b(?:about|on|for|re)\s+(?:the\s+)?([a-z0-9 \-]{3,45})", message, re.I)
    if m:
        return m.group(1).strip().rstrip(".").capitalize()
    if people:
        return "Catch-up: %s" % ", ".join(p.split()[0] for p in people)
    return "Meeting"


def _document_kind(message: str) -> tuple:
    text = message.lower()
    if re.search(r"\b(slide|deck|presentation)\b", text):
        kind = "slides"
    elif re.search(r"\b(memo|note to|announcement)\b", text):
        kind = "memo"
    else:
        kind = "report"
    m = re.search(r"\b(?:about|on|for|covering)\s+(?:the\s+)?([a-z0-9 ,\-]{4,60})", message, re.I)
    topic = m.group(1).strip().rstrip(".") if m else "Untitled"
    title = topic[:1].upper() + topic[1:] if topic != "Untitled" else "Draft %s" % kind
    return kind, title


def _money(v: float) -> str:
    return "{:,.0f}".format(v)
