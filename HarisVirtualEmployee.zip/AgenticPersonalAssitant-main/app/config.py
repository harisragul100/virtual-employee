"""Runtime configuration.

Everything has a default so the app boots with zero setup (mock mode).
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
WEB_DIR = BASE_DIR / "web"


def _load_dotenv() -> None:
    """Minimal .env loader - avoids a python-dotenv dependency."""
    env_file = BASE_DIR / ".env"
    if not env_file.exists():
        return
    for raw in env_file.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip())


_load_dotenv()


def _flag(name: str, default: bool = True) -> bool:
    return os.environ.get(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


class Settings:
    """Read once at import; surfaced to the UI via /api/config."""

    llm_mode = os.environ.get("AIDE_LLM_MODE", "mock").strip().lower()
    anthropic_api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    model = os.environ.get("AIDE_MODEL", "claude-sonnet-5").strip()

    host = os.environ.get("AIDE_HOST", "127.0.0.1")
    port = int(os.environ.get("AIDE_PORT", "8000"))

    # Research brief s.5: "asks for confirmation before sending, booking,
    # submitting or deleting anything" [ReAct, 5]
    confirm_before_acting = _flag("AIDE_CONFIRM_BEFORE_ACTING", True)
    # Research brief s.5: defences against indirect prompt injection [11]
    prompt_injection_defence = _flag("AIDE_PROMPT_INJECTION_DEFENCE", True)
    # Research brief s.5: data-loss prevention
    dlp = _flag("AIDE_DLP", True)

    @property
    def live_llm_available(self) -> bool:
        return self.llm_mode == "live" and bool(self.anthropic_api_key)

    @property
    def effective_engine(self) -> str:
        if self.live_llm_available:
            return "live:" + self.model
        return "mock"


settings = Settings()
