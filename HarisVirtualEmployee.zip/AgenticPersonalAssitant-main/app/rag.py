"""Knowledge layer: retrieval-augmented generation over approved content.

Implements the brief's s.5 knowledge layer and the RAG design lesson [4]:
answer company questions *from company documents, with citations*. Retrieval is
a dependency-free TF-IDF over sentence-window passages - small enough to read,
good enough for a demo, and swappable for a vector database.

Access control happens *before* scoring: a passage the signed-in user cannot
open is never a retrieval candidate, so the assistant cannot leak it even by
accident.
"""
from __future__ import annotations

import math
import re
from collections import Counter
from typing import Dict, List, Optional

from . import safety, seed

STOPWORDS = set("""
a an the and or but if then than that this these those of in on at to for from by with without
is are was were be been being do does did doing have has had i me my we our you your they them
their it its as about into over under again further once here there when where why how all any
both each few more most other some such no nor not only own same so too very can will just should
what which who whom whose our ours i'd i'm what's please tell show give need want get got would
could may might must shall about does do
""".split())

_WORD = re.compile(r"[a-z0-9&']+")

_PASSAGE_CACHE: Optional[List[Dict]] = None
_IDF: Dict[str, float] = {}
# A term the corpus has never seen is maximally rare, not maximally common -
# scoring it as common is what lets an off-topic question match a policy on
# the strength of the word "policy" alone.
_UNSEEN_IDF: float = 3.0

# A retrieved passage must cover this share of the question's information
# weight before it counts as an answer. Below it, saying "I could not find
# that" is the correct output.
MIN_COVERAGE = 0.34

# How many extra times a title term counts towards a passage's weight.
TITLE_WEIGHT = 3


def _tokenise(text: str) -> List[str]:
    # Single characters are noise except digits: "grade 4", "P1" and "5 days"
    # all hang on the number, and dropping it loses the question.
    return [w for w in _WORD.findall(text.lower())
            if w not in STOPWORDS and (len(w) > 1 or w.isdigit())]


def split_sentences(text: str) -> List[str]:
    """Split on sentence ends, then glue short label fragments to what follows.

    Policy documents are written as "Carry-over. Up to 5 unused days may be..."
    A naive split leaves "Carry-over." as a useless standalone sentence, which
    then gets quoted back at the user as if it were an answer.
    """
    parts = [p.strip() for p in re.split(r"(?<=[.!?])\s+", text.strip()) if p.strip()]
    merged: List[str] = []
    for part in parts:
        if merged and len(merged[-1].split()) <= 3 and merged[-1].endswith("."):
            merged[-1] = merged[-1].rstrip(".") + ": " + part
        else:
            merged.append(part)
    return merged


_split_sentences = split_sentences


def _build_index() -> List[Dict]:
    """Chunk every document into overlapping 3-sentence passages."""
    global _PASSAGE_CACHE, _IDF
    if _PASSAGE_CACHE is not None:
        return _PASSAGE_CACHE

    passages: List[Dict] = []
    for doc in seed.DOCUMENTS:
        sentences = _split_sentences(doc["text"])
        window, step = 3, 2
        for start in range(0, max(1, len(sentences)), step):
            chunk = " ".join(sentences[start:start + window])
            if not chunk:
                continue
            # A document's title says what it is about, so its terms count for
            # more than an incidental mention in the body. Without this, a
            # question about "my first two weeks" matches the leave policy's
            # "first two weeks of January" ahead of the New Joiner Guide.
            tokens = Counter(_tokenise(chunk))
            for term in _tokenise(doc["title"]):
                tokens[term] += TITLE_WEIGHT

            passages.append({
                "doc_id": doc["id"],
                "title": doc["title"],
                "owner": doc["owner"],
                "url": doc["url"],
                "last_reviewed": doc["last_reviewed"],
                "groups": doc["groups"],
                "passage_no": len(passages),
                "text": chunk,
                "tokens": tokens,
            })

    n = len(passages)
    df: Counter = Counter()
    for p in passages:
        for term in p["tokens"]:
            df[term] += 1
    global _UNSEEN_IDF
    _IDF = {t: math.log((n + 1) / (c + 0.5)) + 1.0 for t, c in df.items()}
    _UNSEEN_IDF = math.log((n + 1) / 0.5) + 1.0
    for p in passages:
        norm = math.sqrt(sum((tf * _IDF.get(t, 1.0)) ** 2 for t, tf in p["tokens"].items())) or 1.0
        p["norm"] = norm

    _PASSAGE_CACHE = passages
    return passages


def _idf_of(term: str) -> float:
    return _IDF.get(term, _UNSEEN_IDF)


def search(query: str, user_id: str, top_k: int = 5, min_score: float = 0.06) -> Dict:
    """Retrieve passages the user is allowed to see, best first."""
    passages = _build_index()
    groups = set(seed.USERS_BY_ID.get(user_id, {}).get("groups", []))

    q_tokens = Counter(_tokenise(query))
    if not q_tokens:
        return {"hits": [], "withheld": 0, "query": query}
    q_norm = math.sqrt(sum((tf * _idf_of(t)) ** 2 for t, tf in q_tokens.items())) or 1.0
    q_mass = sum(tf * _idf_of(t) for t, tf in q_tokens.items())

    scored, withheld_docs = [], set()
    for p in passages:
        dot = 0.0
        for term, tf in q_tokens.items():
            if term in p["tokens"]:
                idf = _idf_of(term)
                dot += (tf * idf) * (p["tokens"][term] * idf)
        if dot <= 0:
            continue
        score = dot / (q_norm * p["norm"])
        if score < min_score:
            continue
        if not groups.intersection(p["groups"]):
            # Relevant, but out of the user's reach. Count it, never return it.
            withheld_docs.add(p["doc_id"])
            continue
        scored.append((score, p))

    scored.sort(key=lambda t: t[0], reverse=True)

    # Does the best passage actually address the question, or does it merely
    # share a common word with it?
    coverage = 0.0
    if scored and q_mass:
        best_tokens = scored[0][1]["tokens"]
        coverage = sum(tf * _idf_of(t) for t, tf in q_tokens.items() if t in best_tokens) / q_mass
    if scored and coverage < MIN_COVERAGE:
        if withheld_docs:
            from . import store
            store.log("permission_denied", user_id, reason="knowledge_acl",
                      detail="%d relevant document(s) withheld" % len(withheld_docs))
        return {"hits": [], "withheld": len(withheld_docs), "query": query,
                "weak": True, "coverage": round(coverage, 2)}

    hits, seen_docs = [], Counter()
    for score, p in scored:
        # Up to three windows from one document: a short policy often answers
        # a question across two or three consecutive sentences, and cutting at
        # two can drop the very line the reader asked about.
        if seen_docs[p["doc_id"]] >= 3:
            continue
        seen_docs[p["doc_id"]] += 1
        hits.append({
            "doc_id": p["doc_id"],
            "title": p["title"],
            "owner": p["owner"],
            "url": p["url"],
            "last_reviewed": p["last_reviewed"],
            "snippet": p["text"],
            "score": round(score, 3),
            "stale": _is_stale(p["last_reviewed"]),
        })
        if len(hits) >= top_k:
            break

    if withheld_docs:
        from . import store
        store.log("permission_denied", user_id, reason="knowledge_acl",
                  detail="%d relevant document(s) withheld: outside your access groups"
                         % len(withheld_docs))

    return {"hits": hits, "withheld": len(withheld_docs), "query": query,
            "weak": False, "coverage": round(coverage, 2)}


def _is_stale(last_reviewed: str, months: int = 12) -> bool:
    """Freshness metadata the brief asks for: flag content nobody has reviewed."""
    from datetime import date
    try:
        y, m, d = (int(x) for x in last_reviewed.split("-"))
    except Exception:
        return False
    age_days = (date.today() - date(y, m, d)).days
    return age_days > months * 30


def idf(term: str) -> float:
    """Inverse document frequency for a term, building the index if needed."""
    _build_index()
    return _IDF.get(term, 2.0)


def sources(hits: List[Dict]) -> List[Dict]:
    """Collapse passages to one numbered entry per document, best first.

    Citation markers point at documents, not at chunks - two [n] markers that
    resolve to the same policy would just look like a bug to the reader.
    """
    out: List[Dict] = []
    by_id: Dict[str, Dict] = {}
    for h in hits:
        existing = by_id.get(h["doc_id"])
        if existing:
            existing["snippets"].append(h["snippet"])
            continue
        entry = dict(h)
        entry["index"] = len(out) + 1
        entry["snippets"] = [h["snippet"]]
        by_id[h["doc_id"]] = entry
        out.append(entry)
    return out


def source_index(hits: List[Dict]) -> Dict[str, int]:
    return {s["doc_id"]: s["index"] for s in sources(hits)}


def citation_lines(hits: List[Dict]) -> List[str]:
    lines = []
    for s in sources(hits):
        flag = "  *(review overdue)*" if s["stale"] else ""
        lines.append("[%d] %s - %s, reviewed %s%s"
                     % (s["index"], s["title"], s["owner"], s["last_reviewed"], flag))
    return lines


def corpus_stats(user_id: str) -> Dict:
    passages = _build_index()
    visible = safety.visible_documents(user_id)
    return {
        "documents_total": len(seed.DOCUMENTS),
        "documents_visible": len(visible),
        "documents_withheld": len(seed.DOCUMENTS) - len(visible),
        "passages": len(passages),
        "visible_titles": [d["title"] for d in visible],
    }
