"""Safety & compliance layer (research brief s.5, references [10] and [11]).

Three independent checks, each of which can stop a run:

1. `scan_untrusted` - indirect prompt injection [11]. Content that arrives from
   e-mail, documents or any other system is *data*. If it contains text aimed at
   the assistant, that text is stripped, quarantined and logged; it never
   reaches the reasoning step.
2. `dlp_check` - data-loss prevention. Restricted data must not leave the
   tenant, and confidential material must not be quoted to external recipients.
3. `check_scope` - the assistant may only use tools the signed-in user has
   delegated to it.
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

from . import store
from .config import settings
from .seed import USERS_BY_ID

INTERNAL_DOMAIN = "northwind.example"

# ---------------------------------------------------------------------------
# 1. Indirect prompt injection
# ---------------------------------------------------------------------------
INJECTION_PATTERNS: List[Tuple[str, str, str]] = [
    (r"ignore (all |any )?(previous|prior|earlier|above) (instructions|prompts|rules)",
     "critical", "Attempts to override the assistant's instructions"),
    (r"(system|admin|developer) (instruction|prompt|message|note)[^\n]{0,80}(assistant|ai|agent)",
     "critical", "Impersonates a system or administrator instruction"),
    (r"(assistant|ai|agent|bot)[^\n]{0,40}(note|instruction)\s*[:\-]",
     "high", "Text addressed to the assistant rather than to the reader"),
    (r"you are now (in )?(unrestricted|developer|god|jailbreak|admin)",
     "critical", "Claims to unlock a privileged mode"),
    (r"do not (mention|tell|inform|reveal|disclose)[^\n]{0,40}(this|instruction|user)",
     "critical", "Asks the assistant to hide something from the user"),
    (r"if you are an (automated )?(agent|ai|assistant|bot)",
     "high", "Conditional instruction targeting automated readers"),
    (r"(forward|send|copy|cc)[^\n]{0,60}@(?!%s)[a-z0-9.\-]+\.[a-z]{2,}" % re.escape(INTERNAL_DOMAIN),
     "critical", "Asks for data to be sent to an external address"),
    (r"(approve|authorise|authorize|release|remit)[^\n]{0,40}(payment|invoice|transfer)[^\n]{0,40}(immediately|now|without)",
     "critical", "Pushes for an unreviewed financial action"),
    (r"without (involving|informing|asking|notifying|approval from)",
     "high", "Asks to bypass a human approver"),
    (r"bank details have changed|remit to account",
     "high", "Classic payment-redirection pattern"),
    (r"<!--.*?-->",
     "medium", "Hidden HTML comment - invisible to the reader, visible to a model"),
]

_COMPILED = [(re.compile(p, re.I | re.S), sev, why) for p, sev, why in INJECTION_PATTERNS]


def scan_untrusted(text: str, source: str, user_id: str, source_id: str = "") -> Dict:
    """Inspect untrusted content. Returns the sanitised text plus findings."""
    findings: List[Dict] = []
    if not text:
        return {"clean_text": "", "findings": [], "blocked": False}

    if not settings.prompt_injection_defence:
        return {"clean_text": text, "findings": [], "blocked": False, "defence_off": True}

    clean = text
    for rx, severity, why in _COMPILED:
        for match in rx.finditer(text):
            excerpt = match.group(0)
            findings.append({
                "severity": severity,
                "why": why,
                "excerpt": (excerpt[:180] + "...") if len(excerpt) > 180 else excerpt,
                "source": source,
                "source_id": source_id,
            })
            clean = clean.replace(excerpt, "[content removed by injection filter]")

    if findings:
        worst = "critical" if any(f["severity"] == "critical" for f in findings) else "high"
        store.quarantine.append({
            "id": store.new_id("quar"),
            "at": store.now_iso(),
            "user": user_id,
            "source": source,
            "source_id": source_id,
            "severity": worst,
            "findings": findings,
            "original_excerpt": text[:600],
        })
        store.log("injection_blocked", user_id, source=source, source_id=source_id,
                  severity=worst, count=len(findings),
                  detail="; ".join(sorted({f["why"] for f in findings})))

    return {
        "clean_text": clean,
        "findings": findings,
        "blocked": any(f["severity"] == "critical" for f in findings),
    }


# ---------------------------------------------------------------------------
# 2. Data-loss prevention
# ---------------------------------------------------------------------------
DLP_PATTERNS: List[Tuple[str, str, str]] = [
    (r"\b(?:\d[ -]?){13,19}\b", "Payment card number", "restricted"),
    (r"\b[A-Z]{2}\d{2}[ ]?[A-Z0-9]{4}(?:[ ]?[A-Z0-9]{4}){2,5}\b", "IBAN", "restricted"),
    (r"\b\d{3}-\d{2}-\d{4}\b", "US social security number", "restricted"),
    (r"\b(?:passport|national insurance|nin|aadhaar)\s*(?:no\.?|number)?\s*[:#]?\s*[A-Z0-9]{6,12}\b",
     "Government identifier", "restricted"),
    (r"salary band|grade \d+ (specialist|associate|lead)[^\n]{0,40}(usd|\$)\s?\d",
     "Salary band data", "confidential"),
    (r"target bonus \d+ percent", "Reward data", "confidential"),
]
_DLP_COMPILED = [(re.compile(p, re.I), label, cls) for p, label, cls in DLP_PATTERNS]


def is_external(address: str) -> bool:
    return bool(address) and INTERNAL_DOMAIN not in address.lower()


def dlp_check(content: str, recipients: Optional[List[str]], user_id: str, action: str) -> Dict:
    """Decide whether content may leave. Confidential blocks only externally."""
    if not settings.dlp:
        return {"allowed": True, "findings": [], "dlp_off": True}

    recipients = recipients or []
    external = [r for r in recipients if is_external(r)]
    findings: List[Dict] = []

    for rx, label, classification in _DLP_COMPILED:
        m = rx.search(content or "")
        if not m:
            continue
        blocks = classification == "restricted" or (classification == "confidential" and external)
        findings.append({
            "label": label,
            "classification": classification,
            "excerpt": m.group(0)[:60],
            "blocking": blocks,
        })

    # Confidential source material must not be quoted to an outside address.
    blocking = [f for f in findings if f["blocking"]]
    result = {
        "allowed": not blocking,
        "findings": findings,
        "external_recipients": external,
    }
    if blocking:
        store.log("dlp_blocked", user_id, action=action,
                  recipients=recipients,
                  detail="; ".join("%s (%s)" % (f["label"], f["classification"]) for f in blocking))
    return result


# ---------------------------------------------------------------------------
# 3. Delegated permissions
# ---------------------------------------------------------------------------
def check_scope(user_id: str, scope: str, tool: str) -> Dict:
    user = USERS_BY_ID.get(user_id, {})
    held = user.get("scopes", [])
    if scope in held:
        return {"allowed": True}
    store.log("scope_denied", user_id, tool=tool, scope=scope)
    return {
        "allowed": False,
        "reason": (
            "Your account has not delegated the '%s' permission to the assistant, so I cannot "
            "use %s on your behalf. Ask IT to add it, or do this step yourself." % (scope, tool)
        ),
    }


def visible_documents(user_id: str) -> List[Dict]:
    """Documents this user may see. The assistant inherits the user's access."""
    from . import seed
    groups = set(USERS_BY_ID.get(user_id, {}).get("groups", []))
    return [d for d in seed.DOCUMENTS if groups.intersection(d["groups"])]


def hidden_document_count(user_id: str) -> int:
    from . import seed
    return len(seed.DOCUMENTS) - len(visible_documents(user_id))
