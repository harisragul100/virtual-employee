/* Aide - front end. Vanilla JS, no build step, no dependencies. */

const state = {
  config: null,
  users: [],
  userId: null,
  session: null,
  turns: [],          // {role:'user'|'assistant', ...}
  view: 'chat',
  busy: false,
  pending: 0,
};

/* ------------------------------------------------------------------ api */
async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok && data.ok === undefined) throw new Error(data.detail || res.statusText);
  return data;
}

/* ------------------------------------------------------- tiny markdown */
const esc = (s) => String(s ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function inline(s) {
  return esc(s)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[\s(])_([^_]+)_($|[\s.,;:)])/g, '$1<em>$2</em>$3')
    .replace(/(^|[\s(])\*([^*]+)\*($|[\s.,;:)])/g, '$1<em>$2</em>$3');
}

function markdown(src) {
  const lines = String(src || '').split('\n');
  const out = [];
  let i = 0;

  const flushPara = (buf) => { if (buf.length) out.push('<p>' + inline(buf.join(' ')) + '</p>'); };

  while (i < lines.length) {
    const line = lines[i];

    if (!line.trim()) { i++; continue; }

    // heading
    let m = line.match(/^(#{1,4})\s+(.*)$/);
    if (m) { const l = m[1].length; out.push(`<h${l}>${inline(m[2])}</h${l}>`); i++; continue; }

    // horizontal rule
    if (/^\s*---+\s*$/.test(line)) { out.push('<hr>'); i++; continue; }

    // table
    if (/^\s*\|/.test(line) && i + 1 < lines.length && /^\s*\|[\s:|-]+\|?\s*$/.test(lines[i + 1])) {
      const cells = (r) => r.trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim());
      const head = cells(line);
      const align = cells(lines[i + 1]).map((c) => (/-:$/.test(c) ? ' class="num"' : ''));
      i += 2;
      const rows = [];
      while (i < lines.length && /^\s*\|/.test(lines[i])) { rows.push(cells(lines[i])); i++; }
      out.push('<div class="scroll-x"><table><thead><tr>' +
        head.map((h, x) => `<th${align[x] || ''}>${inline(h)}</th>`).join('') +
        '</tr></thead><tbody>' +
        rows.map((r) => '<tr>' + r.map((c, x) => `<td${align[x] || ''}>${inline(c)}</td>`).join('') + '</tr>').join('') +
        '</tbody></table></div>');
      continue;
    }

    // blockquote
    if (/^>\s?/.test(line)) {
      const buf = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) { buf.push(lines[i].replace(/^>\s?/, '')); i++; }
      out.push('<blockquote>' + inline(buf.join('\n')) + '</blockquote>');
      continue;
    }

    // list
    if (/^\s*([-*]|\d+\.)\s+/.test(line)) {
      const ordered = /^\s*\d+\.\s+/.test(line);
      const items = [];
      while (i < lines.length && /^\s*([-*]|\d+\.)\s+/.test(lines[i])) {
        let text = lines[i].replace(/^\s*([-*]|\d+\.)\s+/, '');
        // Checkbox markers become sentinels so escaping cannot mangle them,
        // then get swapped for markup after the inline pass.
        text = text.replace(/^\[([ xX])\]\s*/, (_, c) => (c.trim() ? '\u0001done\u0001' : '\u0001todo\u0001'));
        i++;
        // continuation lines belonging to this item
        while (i < lines.length && /^\s{2,}\S/.test(lines[i]) && !/^\s*([-*]|\d+\.)\s+/.test(lines[i])) {
          text += ' ' + lines[i].trim(); i++;
        }
        const html = inline(text)
          .replace(/\u0001done\u0001/g, '<span style="color:var(--ok)">&#10003;</span> ')
          .replace(/\u0001todo\u0001/g, '<span class="muted">&#9744;</span> ');
        items.push(`<li>${html}</li>`);
      }
      out.push((ordered ? '<ol>' : '<ul>') + items.join('') + (ordered ? '</ol>' : '</ul>'));
      continue;
    }

    // paragraph
    const buf = [];
    while (i < lines.length && lines[i].trim() && !/^(#{1,4}\s|>\s?|\s*[-*]\s|\s*\d+\.\s|\s*\|)/.test(lines[i])
           && !/^\s*---+\s*$/.test(lines[i])) { buf.push(lines[i]); i++; }
    flushPara(buf);
  }
  return out.join('\n');
}

/* --------------------------------------------------------------- utils */
const el = (tag, attrs = {}, html) => {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === false || v == null) continue;
    if (k === 'class') n.className = v; else n.setAttribute(k, v);
  }
  if (html != null) n.innerHTML = html;
  return n;
};
const fmtTime = (iso) => { try { return new Date(iso).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch { return iso; } };
const RISK = { low: 'pill', medium: 'pill warn', high: 'pill off' };

/* ---------------------------------------------------------------- boot */
async function boot() {
  state.config = await api('/api/config');
  state.users = (await api('/api/users')).users;
  state.userId = state.users[0].id;
  renderTopbar();
  document.querySelectorAll('.nav button[data-view]').forEach((b) => {
    b.onclick = () => { state.view = b.dataset.view; renderNav(); render(); };
  });
  document.getElementById('resetBtn').onclick = async () => {
    if (!confirm('Reset the scenario? All drafts, approvals, tickets and metrics are cleared.')) return;
    await api('/api/reset', { method: 'POST' });
    state.turns = []; await switchUser(state.userId);
  };
  await switchUser(state.userId);
}

async function switchUser(id) {
  state.userId = id;
  state.session = await api('/api/session/' + id);
  state.turns = [];
  await refreshPending();
  renderTopbar(); render();
}

async function refreshPending() {
  const r = await api(`/api/actions?user_id=${state.userId}&status=pending`);
  state.pending = r.pending;
  renderNav();
}

function renderNav() {
  document.querySelectorAll('.nav button[data-view]').forEach((b) =>
    b.classList.toggle('active', b.dataset.view === state.view));
  const badge = document.getElementById('pendingBadge');
  badge.hidden = !state.pending;
  badge.textContent = state.pending;
}

function renderTopbar() {
  const box = document.getElementById('userpick');
  box.innerHTML = '';
  for (const u of state.users) {
    const b = el('button', { 'aria-pressed': String(u.id === state.userId), title: `${u.role} - ${u.department}` });
    b.innerHTML = `<span class="avatar">${u.avatar}</span><span class="who"><b>${esc(u.name.split(' ')[0])}</b><span>${esc(u.role.split('(')[0].trim())}</span></span>`;
    b.onclick = () => switchUser(u.id);
    box.appendChild(b);
  }
  const g = state.config.guardrails;
  document.getElementById('guardrails').innerHTML = [
    ['Confirm before acting', g.confirm_before_acting],
    ['Injection defence', g.prompt_injection_defence],
    ['DLP', g.dlp],
  ].map(([label, on]) =>
    `<span class="pill ${on ? 'on' : 'off'}" title="${on ? 'Active' : 'Disabled in .env - unsafe'}">${on ? '&#10003;' : '&#10007;'} ${label}</span>`).join('');
  document.getElementById('enginePill').textContent = state.config.engine === 'mock'
    ? 'engine: mock (offline)' : 'engine: ' + state.config.engine;
}

/* --------------------------------------------------------------- views */
function render() {
  const main = document.getElementById('main');
  main.innerHTML = '';
  main.scrollTop = 0;
  ({ chat: viewChat, approvals: viewApprovals, workspace: viewWorkspace,
     knowledge: viewKnowledge, memory: viewMemory, permissions: viewPermissions,
     safety: viewSafety, metrics: viewMetrics, about: viewAbout }[state.view] || viewChat)(main);
}

/* ---------------------------------------------------------------- chat */
function viewChat(main) {
  const wrap = el('div', { class: 'chatwrap' });

  const quick = el('div', { class: 'quickbar' });
  quick.innerHTML = `<div class="label">One-click tasks for ${esc(state.session.user.role)} &mdash; no prompting skill needed</div>`;
  const chips = el('div', { class: 'chips' });
  for (const a of state.session.quick_actions) {
    const c = el('button', { class: 'chip' }, esc(a.label));
    c.onclick = () => send(a.prompt);
    chips.appendChild(c);
  }
  quick.appendChild(chips);
  wrap.appendChild(quick);

  const thread = el('div', { class: 'thread', id: 'thread' });
  if (!state.turns.length) thread.appendChild(welcome());
  else state.turns.forEach((t) => thread.appendChild(t.role === 'user' ? userTurn(t) : assistantTurn(t)));
  wrap.appendChild(thread);

  const comp = el('div', { class: 'composer' });
  comp.innerHTML = `
    <div class="inner">
      <form id="composer">
        <textarea id="input" rows="1" placeholder="Ask in plain language - for example &quot;draft a reply to Ayesha&quot; or &quot;what is our travel policy?&quot;"></textarea>
        <button class="send" type="submit" id="sendBtn">Send</button>
      </form>
      <div class="note">Aide never sends, books, submits or deletes anything until you approve it. You remain responsible for what you approve.</div>
    </div>`;
  wrap.appendChild(comp);
  main.appendChild(wrap);

  const input = document.getElementById('input');
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 190) + 'px';
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); document.getElementById('composer').requestSubmit(); }
  });
  document.getElementById('composer').onsubmit = (e) => {
    e.preventDefault();
    const v = input.value.trim();
    if (v) { input.value = ''; input.style.height = 'auto'; send(v); }
  };
  input.focus();
  if (state.turns.length) scrollDown();
}

function welcome() {
  const u = state.session.user;
  const box = el('div', { class: 'empty' });
  box.innerHTML = `
    <h2>Good day, ${esc(u.name.split(' ')[0])}.</h2>
    <p>I am signed in as you, with your permissions only &mdash; ${state.session.knowledge.documents_visible}
       of ${state.session.knowledge.documents_visible + state.session.knowledge.documents_withheld}
       company documents are readable by your account.</p>
    <p class="small muted">Pick a task above, or type anything below. I show my working on every answer.</p>`;
  const lib = el('div', { class: 'card mt', style: 'text-align:left;max-width:620px;margin:22px auto 0' });
  lib.innerHTML = '<h3>Prompt library</h3>';
  for (const g of state.session.prompt_library) {
    const grp = el('div', { style: 'margin-bottom:10px' });
    grp.innerHTML = `<div class="label small muted" style="margin-bottom:5px">${esc(g.group)}</div>`;
    const cs = el('div', { class: 'chips' });
    g.items.forEach((t) => { const b = el('button', { class: 'chip' }, esc(t)); b.onclick = () => send(t); cs.appendChild(b); });
    grp.appendChild(cs); lib.appendChild(grp);
  }
  box.appendChild(lib);
  return box;
}

function userTurn(t) {
  const d = el('div', { class: 'turn user' });
  d.appendChild(el('div', { class: 'bubble' }, esc(t.text)));
  return d;
}

function assistantTurn(run) {
  const d = el('div', { class: 'turn' });
  const msg = el('div', { class: 'msg' });

  const conf = Math.round(run.confidence * 100);
  msg.appendChild(el('header', {}, `
    <span class="avatar" style="background:var(--accent)">A</span>
    <span class="name">Aide</span>
    <span class="pill info">${esc(run.intent_label)}</span>
    <span class="pill" title="How sure the router was about the task">${conf}% confident</span>
    <span class="pill" title="Reasoning engine">${esc(run.engine)}</span>`));

  const content = el('div', { class: 'content' });

  for (const n of run.safety_notices) {
    const icon = n.level === 'info' ? '&#8505;' : (n.level === 'warning' ? '&#9888;' : '&#9940;');
    content.appendChild(el('div', { class: 'notice ' + n.level }, `
      <span class="ico">${icon}</span>
      <div><b>${esc(n.text)}</b><span>${esc(n.detail)}</span></div>`));
  }

  content.appendChild(el('div', { class: 'md' }, markdown(run.answer)));

  run.pending_actions.forEach((a) => content.appendChild(approvalCard(a)));

  if (run.citations && run.citations.length) {
    const s = el('div', { class: 'sources' });
    s.innerHTML = '<div class="label">Sources &mdash; click to open the document</div>';
    run.citations.forEach((c, idx) => {
      s.appendChild(el('div', { class: 'src' }, `
        <span class="n">${c.index || idx + 1}</span>
        <div><a href="${esc(c.url)}" target="_blank" rel="noopener">${esc(c.title)}</a>
        <div class="meta">${esc(c.owner)} &middot; reviewed ${esc(c.last_reviewed)}${c.stale ? ' &middot; <span style="color:var(--warn)">review overdue</span>' : ''}</div></div>`));
    });
    content.appendChild(s);
  }

  content.appendChild(traceBlock(run));

  if (run.suggestions && run.suggestions.length) {
    const sg = el('div', { class: 'suggest' });
    run.suggestions.forEach((t) => { const b = el('button', {}, esc(t)); b.onclick = () => send(t); sg.appendChild(b); });
    content.appendChild(sg);
  }

  msg.appendChild(content);

  const foot = el('div', { class: 'msgfoot' });
  const up = el('button', { class: 'iconbtn', title: 'This was useful' }, '&#128077;');
  const down = el('button', { class: 'iconbtn down', title: 'This was not useful' }, '&#128078;');
  const rate = async (rating, btn) => {
    const comment = rating === 'down' ? (prompt('What went wrong? (optional)') || '') : '';
    await api('/api/feedback', { method: 'POST', body: { user_id: state.userId, run_id: run.id, rating, comment } });
    up.classList.remove('chosen'); down.classList.remove('chosen');
    btn.classList.add('chosen');
    foot.querySelector('.hint').textContent = 'Thanks - logged against the quality metric.';
  };
  up.onclick = () => rate('up', up);
  down.onclick = () => rate('down', down);
  foot.append(up, down, el('span', { class: 'hint' }, `Task baseline: ${run.baseline_minutes} min unaided`));
  msg.appendChild(foot);

  d.appendChild(msg);
  return d;
}

function traceBlock(run) {
  const det = el('details', { class: 'trace' });
  const toolCount = run.trace.filter((s) => s.type === 'tool').length;
  det.appendChild(el('summary', {}, `How I did this &mdash; ${toolCount} tool call${toolCount === 1 ? '' : 's'}, ${run.trace.length} step${run.trace.length === 1 ? '' : 's'}`));
  const steps = el('div', { class: 'steps' });

  for (const s of run.trace) {
    const n = el('div', { class: 'step ' + s.type });
    if (s.type === 'routing') {
      n.innerHTML = `<div class="head"><span class="kind">route</span><b>${esc(s.intent_label)}</b>
        <span class="pill">${Math.round(s.confidence * 100)}%</span></div>
        <div class="obs">${esc(s.reason)}${s.runner_up ? ' &middot; runner-up: ' + esc(s.runner_up) : ''}</div>`;
    } else if (s.type === 'tool') {
      n.innerHTML = `<div class="head"><span class="kind">tool</span><code>${esc(s.tool)}</code>
        <span class="tag read">read</span><span class="tag">${esc(s.system)}</span>
        <span class="tag">scope: ${esc(s.scope)}</span></div>
        ${Object.keys(s.args || {}).length ? `<div class="args">${esc(JSON.stringify(s.args))}</div>` : ''}
        <div class="obs">&#8627; ${esc(s.observation)}</div>`;
    } else if (s.type === 'staged') {
      n.innerHTML = `<div class="head"><span class="kind">staged for approval</span><code>${esc(s.tool)}</code>
        <span class="tag write">write</span><span class="tag">${esc(s.system)}</span></div>
        <div class="obs">${esc(s.text)} &mdash; held, not executed</div>`;
    } else if (s.type === 'safety') {
      n.innerHTML = `<div class="head"><span class="kind">safety</span><b>${esc(s.text)}</b></div>
        <div class="obs">${esc(s.detail)}</div>`;
    } else {
      n.innerHTML = `<div class="head"><span class="kind">${esc(s.type)}</span></div><div class="obs">${esc(s.text)}</div>`;
    }
    steps.appendChild(n);
  }
  det.appendChild(steps);
  return det;
}

/* --------------------------------------------------- the approval card */
function approvalCard(a, compact = false) {
  const card = el('div', { class: 'approval' + (a.status !== 'pending' ? ' done' : ''), id: 'act-' + a.id });
  const risk = RISK[a.risk] || 'pill';
  const statusPill = a.status === 'pending'
    ? '<span class="pill warn">awaiting your approval</span>'
    : (a.status === 'approved' ? '<span class="pill on">approved</span>' : '<span class="pill off">rejected</span>');

  card.appendChild(el('header', {}, `
    <span class="t">${esc(a.summary)}</span>
    <span class="${risk}">${esc(a.risk)} risk</span>
    <span class="pill">${esc(a.system)}</span>
    <span class="pill mono" title="Tool that will run">${esc(a.tool)}</span>
    ${statusPill}`));

  const inner = el('div', { class: 'inner' });
  inner.appendChild(el('div', { class: 'why' }, esc(a.why)));

  if (a.dlp_findings && a.dlp_findings.length) {
    inner.appendChild(el('div', { class: 'notice warning' }, `<span class="ico">&#9888;</span>
      <div><b>Data-loss prevention noticed something</b><span>${a.dlp_findings.map((f) => esc(f.label) + ' (' + esc(f.classification) + ')').join('; ')}</span></div>`));
  }

  const inputs = {};
  if (a.status === 'pending') {
    for (const f of a.fields) {
      const fld = el('div', { class: 'field' });
      fld.appendChild(el('label', {}, esc(f.label)));
      const inp = f.multiline ? el('textarea') : el('input', { type: 'text' });
      inp.value = f.value;
      fld.appendChild(inp);
      if (f.multiline) {
        // Grow to fit the draft: a reply the reader has to scroll inside a
        // 100px box is a reply they will approve without reading.
        const fit = () => { inp.style.height = 'auto'; inp.style.height = Math.min(inp.scrollHeight + 2, 460) + 'px'; };
        inp.addEventListener('input', fit);
        requestAnimationFrame(fit);
      }
      inputs[f.key] = inp;
      inner.appendChild(fld);
    }
  } else {
    const dl = el('div', { class: 'kv small' });
    a.fields.forEach((f) => {
      dl.appendChild(el('div', { class: 'k' }, esc(f.label)));
      dl.appendChild(el('div', {}, esc(String(f.value).slice(0, 400))));
    });
    inner.appendChild(dl);
  }

  const actions = el('div', { class: 'actions' });
  const result = el('span', { class: 'result' });

  if (a.status === 'pending') {
    const ok = el('button', { class: 'btn approve' }, '&#10003; Approve and run');
    const no = el('button', { class: 'btn reject' }, 'Reject');
    ok.onclick = async () => {
      ok.disabled = no.disabled = true;
      const edits = {};
      for (const [k, inp] of Object.entries(inputs)) edits[k] = inp.value;
      const r = await api(`/api/actions/${a.id}/approve`, { method: 'POST', body: { edits } });
      if (r.ok) {
        a.status = 'approved';
        card.classList.add('done');
        card.querySelector('header .pill.warn').outerHTML = '<span class="pill on">approved</span>';
        actions.innerHTML = '';
        result.textContent = '✓ ' + r.receipt;
        actions.appendChild(result);
        Object.values(inputs).forEach((i) => { i.disabled = true; });
      } else {
        result.className = 'result bad';
        result.textContent = r.error;
        ok.disabled = no.disabled = false;
      }
      refreshPending();
    };
    no.onclick = async () => {
      const reason = prompt('Why are you rejecting it? (optional - it goes in the audit log)') || '';
      const r = await api(`/api/actions/${a.id}/reject`, { method: 'POST', body: { reason } });
      if (r.ok) {
        a.status = 'rejected';
        card.classList.add('done');
        card.querySelector('header .pill.warn').outerHTML = '<span class="pill off">rejected</span>';
        actions.innerHTML = '';
        result.className = 'result bad';
        result.textContent = 'Rejected - nothing was sent.';
        actions.appendChild(result);
        Object.values(inputs).forEach((i) => { i.disabled = true; });
      }
      refreshPending();
    };
    actions.append(ok, no, el('span', { class: 'small muted' }, 'Edit any field before approving.'));
  } else if (a.status === 'approved') {
    result.textContent = '✓ ' + ((a.result && a.result.receipt) || 'Done') +
      (a.edited ? '  (you edited the draft first)' : '');
    actions.appendChild(result);
  } else {
    result.className = 'result bad';
    result.textContent = 'Rejected' + (a.reason ? ' - ' + a.reason : '') + '. Nothing was sent.';
    actions.appendChild(result);
  }

  inner.appendChild(actions);
  card.appendChild(inner);
  return card;
}

/* -------------------------------------------------------------- send() */
async function send(text) {
  if (state.busy) return;
  if (state.view !== 'chat') { state.view = 'chat'; renderNav(); render(); }
  state.busy = true;

  state.turns.push({ role: 'user', text });
  const thread = document.getElementById('thread');
  if (thread.querySelector('.empty')) thread.innerHTML = '';
  thread.appendChild(userTurn({ text }));

  const think = el('div', { class: 'turn' }, `<div class="thinking"><span class="dots"><i></i><i></i><i></i></span> Working &mdash; reading only what your account can see&hellip;</div>`);
  thread.appendChild(think);
  document.getElementById('sendBtn').disabled = true;
  scrollDown();

  try {
    const run = await api('/api/chat', { method: 'POST', body: { user_id: state.userId, message: text } });
    state.turns.push({ role: 'assistant', ...run });
    think.replaceWith(assistantTurn(run));
  } catch (err) {
    think.replaceWith(el('div', { class: 'turn' }, `<div class="notice critical"><span class="ico">&#9940;</span><div><b>Request failed</b><span>${esc(err.message)}</span></div></div>`));
  } finally {
    state.busy = false;
    const b = document.getElementById('sendBtn'); if (b) b.disabled = false;
    refreshPending(); scrollDown();
  }
}

function scrollDown() {
  const m = document.getElementById('main');
  requestAnimationFrame(() => { m.scrollTop = m.scrollHeight; });
}

/* ---------------------------------------------------------- approvals */
async function viewApprovals(main) {
  const v = el('div', { class: 'view' });
  v.innerHTML = `<header><h1>Approvals</h1>
    <p>Every action that would send, book, submit or change something waits here.
       This is the gate the research calls for: agents still fail often on real office tasks,
       so a person stays on the trigger.</p></header>`;
  main.appendChild(v);

  const data = await api(`/api/actions?user_id=${state.userId}`);
  if (!data.actions.length) {
    v.appendChild(el('div', { class: 'card' }, '<p class="muted">Nothing staged yet. Ask the assistant to draft a reply, book a meeting or raise a ticket.</p>'));
    return;
  }
  const pending = data.actions.filter((a) => a.status === 'pending');
  const done = data.actions.filter((a) => a.status !== 'pending');
  if (pending.length) {
    v.appendChild(el('h3', { style: 'margin:18px 0 8px;font-size:13px' }, `Waiting for you (${pending.length})`));
    pending.forEach((a) => v.appendChild(approvalCard(a)));
  }
  if (done.length) {
    v.appendChild(el('h3', { style: 'margin:22px 0 8px;font-size:13px' }, `Decided (${done.length})`));
    done.forEach((a) => v.appendChild(approvalCard(a)));
  }
}

/* ---------------------------------------------------------- workspace */
async function viewWorkspace(main) {
  const w = await api('/api/workspace/' + state.userId);
  const v = el('div', { class: 'view wide' });
  v.innerHTML = `<header><h1>Workspace</h1>
    <p>The mock systems behind the assistant. Everything the assistant creates lands here,
       and only after you approved it.</p></header>`;

  const section = (title, rows, cols, emptyMsg) => {
    const c = el('div', { class: 'card' });
    c.innerHTML = `<h3>${esc(title)} <span class="pill">${rows.length}</span></h3>`;
    if (!rows.length) { c.appendChild(el('p', { class: 'muted small' }, emptyMsg)); return c; }
    const t = el('table', { class: 'data' });
    t.innerHTML = '<thead><tr>' + cols.map((c2) => `<th>${esc(c2[0])}</th>`).join('') + '</tr></thead>';
    const tb = el('tbody');
    rows.forEach((r) => {
      const tr = el('tr');
      cols.forEach((c2) => tr.appendChild(el('td', {}, c2[1](r))));
      tb.appendChild(tr);
    });
    t.appendChild(tb);
    c.appendChild(el('div', { class: 'scroll-x' })).appendChild(t);
    return c;
  };

  v.appendChild(section('Inbox', w.inbox, [
    ['From', (r) => esc(r.from)], ['Subject', (r) => esc(r.subject)],
    ['Received', (r) => fmtTime(r.received)],
    ['State', (r) => (r.unread ? '<span class="pill info">unread</span>' : '') +
      (r.awaiting_reply ? ` <span class="pill warn">awaiting reply ${r.waiting_days}d</span>` : '') +
      (r.external ? ' <span class="pill">external</span>' : '')],
  ], 'Empty.'));

  v.appendChild(section('Sent by the assistant (after your approval)', w.sent, [
    ['To', (r) => esc(r.to.join(', '))], ['Subject', (r) => esc(r.subject)],
    ['Sent', (r) => fmtTime(r.sent_at)],
  ], 'Nothing sent yet - approve a drafted reply and it will appear here.'));

  v.appendChild(section('Calendar', w.calendar, [
    ['Title', (r) => esc(r.title) + (r.created_by === 'assistant' ? ' <span class="pill info">booked via Aide</span>' : '')],
    ['Start', (r) => fmtTime(r.start)], ['End', (r) => fmtTime(r.end)],
    ['Attendees', (r) => esc((r.attendees || []).join(', '))],
  ], 'Nothing in the diary.'));

  v.appendChild(section('Tasks', w.tasks, [
    ['Task', (r) => esc(r.title)], ['Due', (r) => esc(r.due || '-')],
    ['Done', (r) => (r.done ? 'yes' : 'no')],
  ], 'No tasks yet.'));

  v.appendChild(section('Service-desk tickets', w.tickets, [
    ['Ref', (r) => esc(r.id)], ['Title', (r) => esc(r.title)],
    ['Priority', (r) => `<span class="pill">${esc(r.priority)}</span>`], ['Status', (r) => esc(r.status)],
  ], 'No tickets.'));

  v.appendChild(section('Leave requests', w.leave_requests, [
    ['Dates', (r) => `${esc(r.start_date)} to ${esc(r.end_date)}`], ['Days', (r) => String(r.days)],
    ['Approver', (r) => esc(r.approver)], ['Status', (r) => esc(r.status)],
  ], 'No leave requested.'));

  v.appendChild(section('Expense claims', w.expense_claims, [
    ['Ref', (r) => esc(r.id)], ['Total', (r) => `${esc(r.currency)} ${r.total.toFixed(2)}`],
    ['Items', (r) => String(r.items.length)], ['Status', (r) => esc(r.status)],
  ], 'No claims.'));

  v.appendChild(section('Documents drafted', w.documents, [
    ['Title', (r) => esc(r.title)], ['Type', (r) => esc(r.format)], ['Created', (r) => fmtTime(r.created)],
  ], 'No documents saved.'));

  main.appendChild(v);
}

/* ---------------------------------------------------------- knowledge */
async function viewKnowledge(main) {
  const k = await api('/api/knowledge/' + state.userId);
  const v = el('div', { class: 'view' });
  v.innerHTML = `<header><h1>Knowledge the assistant can read</h1>
    <p>Retrieval-augmented answers are grounded in these documents and cite them.
       The list is filtered by <b>your</b> access groups &mdash; the assistant inherits your
       permissions and never reads round them.</p></header>`;

  v.appendChild(el('div', { class: 'grid three' }, `
    <div class="stat"><div class="k">Readable by you</div><div class="v">${k.stats.documents_visible}</div><div class="n">of ${k.stats.documents_total} company documents</div></div>
    <div class="stat"><div class="k">Withheld</div><div class="v">${k.withheld}</div><div class="n">outside your access groups</div></div>
    <div class="stat"><div class="k">Indexed passages</div><div class="v">${k.stats.passages}</div><div class="n">TF-IDF over sentence windows</div></div>`));

  const c = el('div', { class: 'card mt' });
  c.innerHTML = '<h3>Documents</h3>';
  const t = el('table', { class: 'data' });
  t.innerHTML = `<thead><tr><th>Title</th><th>Owner</th><th>Access groups</th><th>Last reviewed</th><th>Size</th></tr></thead>`;
  const tb = el('tbody');
  k.documents.forEach((d) => {
    tb.appendChild(el('tr', {}, `
      <td><a href="${esc(d.url)}" target="_blank" rel="noopener">${esc(d.title)}</a></td>
      <td>${esc(d.owner)}</td>
      <td>${d.groups.map((g) => `<span class="tag">${esc(g)}</span>`).join('')}</td>
      <td>${esc(d.last_reviewed)}${d.stale ? ' <span class="pill warn">overdue</span>' : ''}</td>
      <td class="muted">${d.words} words</td>`));
  });
  t.appendChild(tb);
  c.appendChild(el('div', { class: 'scroll-x' })).appendChild(t);
  v.appendChild(c);

  if (k.withheld) {
    v.appendChild(el('div', { class: 'notice info' }, `<span class="ico">&#8505;</span>
      <div><b>${k.withheld} document${k.withheld === 1 ? '' : 's'} hidden from you</b>
      <span>Sign in as a different colleague in the top bar to see how the same question gets a
      different answer. That is the delegated-permission model working, not a bug.</span></div>`));
  }
  main.appendChild(v);
}

/* ------------------------------------------------------------- memory */
async function viewMemory(main) {
  const m = (await api('/api/memory/' + state.userId)).memory;
  const v = el('div', { class: 'view' });
  v.innerHTML = `<header><h1>What the assistant remembers about you</h1>
    <p>Long-term memory is only acceptable if the person can see and change it.
       Edit anything here and the next draft uses it. Delete anything you would rather it forgot.</p></header>`;

  const c = el('div', { class: 'card' });
  for (const [key, value] of Object.entries(m)) {
    const f = el('div', { class: 'field' });
    f.appendChild(el('label', {}, esc(key.replace(/_/g, ' '))));
    const row = el('div', { style: 'display:flex;gap:7px;align-items:flex-start' });
    const inp = value.length > 70 ? el('textarea', { style: 'min-height:62px' }) : el('input', { type: 'text' });
    inp.value = value;
    const save = el('button', { class: 'ghost' }, 'Save');
    const del = el('button', { class: 'ghost', title: 'Forget this' }, 'Forget');
    save.onclick = async () => {
      await api('/api/memory', { method: 'POST', body: { user_id: state.userId, key, value: inp.value } });
      save.textContent = 'Saved'; setTimeout(() => { save.textContent = 'Save'; }, 1400);
    };
    del.onclick = async () => {
      await api(`/api/memory/${state.userId}/${encodeURIComponent(key)}`, { method: 'DELETE' });
      render();
    };
    row.append(inp, save, del);
    f.appendChild(row);
    c.appendChild(f);
  }

  const add = el('div', { class: 'field mt', style: 'border-top:1px solid var(--border);padding-top:13px' });
  add.appendChild(el('label', {}, 'Teach it something new'));
  const arow = el('div', { style: 'display:flex;gap:7px' });
  const kk = el('input', { type: 'text', placeholder: 'e.g. preferred_greeting', style: 'max-width:220px' });
  const vv = el('input', { type: 'text', placeholder: 'e.g. always open with "Hi" not "Dear"' });
  const ab = el('button', { class: 'ghost' }, 'Add');
  ab.onclick = async () => {
    if (!kk.value.trim()) return;
    await api('/api/memory', { method: 'POST', body: { user_id: state.userId, key: kk.value.trim().replace(/\s+/g, '_'), value: vv.value } });
    render();
  };
  arow.append(kk, vv, ab);
  add.appendChild(arow);
  c.appendChild(add);
  v.appendChild(c);

  v.appendChild(el('div', { class: 'notice info mt' }, `<span class="ico">&#8505;</span>
    <div><b>Try it</b><span>Change "tone" to something blunt, then ask for a draft reply. Every memory
    change is written to the audit log.</span></div>`));
  main.appendChild(v);
}

/* -------------------------------------------------------- permissions */
function viewPermissions(main) {
  const s = state.session;
  const v = el('div', { class: 'view' });
  v.innerHTML = `<header><h1>Delegated permissions</h1>
    <p>The assistant acts <b>as ${esc(s.user.name)}</b>, using scopes ${esc(s.user.name.split(' ')[0])} has
       delegated to it. A tool whose scope is not granted simply cannot run &mdash; the assistant says so
       rather than finding another way round.</p></header>`;

  const c = el('div', { class: 'card' });
  const t = el('table', { class: 'data' });
  t.innerHTML = '<thead><tr><th>Scope</th><th>Status</th><th>Unlocks these tools</th></tr></thead>';
  const tb = el('tbody');
  s.permissions.forEach((p) => {
    tb.appendChild(el('tr', {}, `
      <td class="mono">${esc(p.scope)}</td>
      <td>${p.granted ? '<span class="pill on">granted</span>' : '<span class="pill off">not granted</span>'}</td>
      <td class="muted">${p.tools.map(esc).join(', ')}</td>`));
  });
  t.appendChild(tb);
  c.appendChild(el('div', { class: 'scroll-x' })).appendChild(t);
  v.appendChild(c);

  const tools = el('div', { class: 'card' });
  tools.innerHTML = `<h3>Tool registry</h3><p class="small muted">Connectors are described the way the
    Model Context Protocol describes them. The one field that matters for safety is
    <b>read</b> versus <b>write</b>: read runs immediately, write is always staged for approval.</p>`;
  const tt = el('table', { class: 'data' });
  tt.innerHTML = '<thead><tr><th>Tool</th><th>Kind</th><th>System</th><th>What it does</th></tr></thead>';
  const ttb = el('tbody');
  state.config.tools.forEach((x) => {
    ttb.appendChild(el('tr', {}, `
      <td class="mono">${esc(x.name)}</td>
      <td><span class="tag ${x.side_effect}">${esc(x.side_effect)}</span></td>
      <td>${esc(x.system)}</td>
      <td class="muted">${esc(x.description)}</td>`));
  });
  tt.appendChild(ttb);
  tools.appendChild(el('div', { class: 'scroll-x' })).appendChild(tt);
  v.appendChild(tools);
  main.appendChild(v);
}

/* ------------------------------------------------------------- safety */
async function viewSafety(main) {
  const s = await api('/api/safety?limit=150');
  const v = el('div', { class: 'view wide' });
  v.innerHTML = `<header><h1>Safety &amp; audit</h1>
    <p>Content arriving from e-mail or documents is data, never instructions. Anything that tries to
       give the assistant orders is stripped, quarantined and logged before the reasoning step sees it.</p></header>`;

  const q = el('div', { class: 'card' });
  q.innerHTML = `<h3>Quarantine <span class="pill ${s.quarantine.length ? 'off' : ''}">${s.quarantine.length}</span></h3>`;
  if (!s.quarantine.length) {
    q.appendChild(el('p', { class: 'muted small' }, 'Nothing quarantined yet. Sign in as Priya and summarise her inbox - one of the messages is booby-trapped.'));
  } else {
    s.quarantine.forEach((item) => {
      const box = el('div', { class: 'notice ' + (item.severity === 'critical' ? 'critical' : 'warning'), style: 'flex-direction:column;gap:7px' });
      box.innerHTML = `<div><b>${esc(item.source)} &middot; ${esc(item.source_id)} &middot; ${esc(item.severity)}</b>
        <span>${esc(item.user)} &middot; ${fmtTime(item.at)}</span></div>`;
      const tbl = el('table', { class: 'data', style: 'background:var(--surface);border-radius:6px' });
      tbl.innerHTML = '<thead><tr><th>Severity</th><th>What it tried</th><th>Offending text</th></tr></thead>';
      const tb = el('tbody');
      item.findings.forEach((f) => tb.appendChild(el('tr', {}, `
        <td><span class="pill ${f.severity === 'critical' ? 'off' : 'warn'}">${esc(f.severity)}</span></td>
        <td>${esc(f.why)}</td><td class="mono">${esc(f.excerpt)}</td>`)));
      tbl.appendChild(tb);
      box.appendChild(el('div', { class: 'scroll-x', style: 'width:100%' })).appendChild(tbl);
      q.appendChild(box);
    });
  }
  v.appendChild(q);

  const a = el('div', { class: 'card' });
  a.innerHTML = `<h3>Audit log <span class="pill">${s.audit_log.length}</span></h3>
    <p class="small muted">Every tool call, approval decision, block and memory change, with the user who caused it.</p>`;
  const t = el('table', { class: 'data' });
  t.innerHTML = '<thead><tr><th>Time</th><th>Event</th><th>User</th><th>Tool / detail</th></tr></thead>';
  const tb = el('tbody');
  const cls = { injection_blocked: 'off', dlp_blocked: 'off', scope_denied: 'off', permission_denied: 'off', action_rejected: 'off', action_approved: 'on', tool_write: 'on', action_staged: 'warn' };
  s.audit_log.forEach((e) => {
    tb.appendChild(el('tr', {}, `
      <td class="muted mono">${fmtTime(e.at)}</td>
      <td><span class="pill ${cls[e.event] || ''}">${esc(e.event)}</span></td>
      <td>${esc(e.user)}</td>
      <td class="muted">${esc([e.tool, e.detail].filter(Boolean).join(' - ')).slice(0, 220)}</td>`));
  });
  t.appendChild(tb);
  a.appendChild(el('div', { class: 'scroll-x' })).appendChild(t);
  v.appendChild(a);
  main.appendChild(v);
}

/* ------------------------------------------------------------ metrics */
async function viewMetrics(main) {
  const m = await api('/api/metrics');
  const v = el('div', { class: 'view wide' });
  v.innerHTML = `<header><h1>Measurement</h1>
    <p>The five measures the research brief asks for: adoption, productivity, quality, experience and
       risk. Everything below comes from what you have actually done in this session.</p></header>`;

  v.appendChild(el('div', { class: 'grid three' }, `
    <div class="stat"><div class="k">Weekly active users</div><div class="v">${m.adoption.weekly_active_users}</div><div class="n">of ${m.adoption.registered_users} registered</div></div>
    <div class="stat"><div class="k">Tasks completed</div><div class="v">${m.adoption.tasks_total}</div><div class="n">${m.adoption.tasks_per_active_user} per active user this week</div></div>
    <div class="stat"><div class="k">Time saved</div><div class="v">${m.productivity.hours_saved}h</div><div class="n">${m.productivity.minutes_saved} minutes against task baselines</div></div>
    <div class="stat"><div class="k">Approval rate</div><div class="v">${m.quality.approval_rate == null ? '-' : m.quality.approval_rate + '%'}</div><div class="n">${m.quality.approved} approved, ${m.quality.rejected} rejected</div></div>
    <div class="stat"><div class="k">Correction rate</div><div class="v">${m.quality.correction_rate == null ? '-' : m.quality.correction_rate + '%'}</div><div class="n">drafts edited before approval</div></div>
    <div class="stat"><div class="k">Satisfaction</div><div class="v">${m.experience.satisfaction_pct == null ? '-' : m.experience.satisfaction_pct + '%'}</div><div class="n">${m.experience.thumbs_up} up, ${m.experience.thumbs_down} down</div></div>`));

  const byIntent = Object.entries(m.productivity.per_intent).sort((a, b) => b[1].minutes_saved - a[1].minutes_saved);
  const p = el('div', { class: 'card mt' });
  p.innerHTML = `<h3>Productivity by task</h3><p class="small muted">${esc(m.productivity.note)}</p>`;
  if (!byIntent.length) p.appendChild(el('p', { class: 'muted small' }, 'Run a few tasks in the chat and this fills in.'));
  else {
    const max = Math.max(...byIntent.map(([, d]) => d.minutes_saved)) || 1;
    const t = el('table', { class: 'data' });
    t.innerHTML = '<thead><tr><th>Task</th><th>Times run</th><th>Unaided baseline</th><th>Minutes saved</th><th style="width:34%"></th></tr></thead>';
    const tb = el('tbody');
    byIntent.forEach(([k, d]) => {
      tb.appendChild(el('tr', {}, `
        <td>${esc(k.replace(/_/g, ' '))}</td><td>${d.tasks}</td><td class="muted">${d.baseline} min</td>
        <td><b>${d.minutes_saved.toFixed(0)} min</b></td>
        <td><div style="height:8px;border-radius:4px;background:var(--accent);width:${Math.max(4, (d.minutes_saved / max) * 100)}%"></div></td>`));
    });
    t.appendChild(tb);
    p.appendChild(el('div', { class: 'scroll-x' })).appendChild(t);
  }
  v.appendChild(p);

  const perUser = Object.entries(m.adoption.per_user);
  const u = el('div', { class: 'card' });
  u.innerHTML = `<h3>Who is using it</h3><p class="small muted">The research finds the largest gains go to
    less-experienced staff, so experience level is tracked alongside usage.</p>`;
  if (!perUser.length) u.appendChild(el('p', { class: 'muted small' }, 'No usage yet.'));
  else {
    const t = el('table', { class: 'data' });
    t.innerHTML = '<thead><tr><th>User</th><th>Experience</th><th>Tasks</th><th>Minutes saved</th></tr></thead>';
    const tb = el('tbody');
    perUser.forEach(([k, d]) => tb.appendChild(el('tr', {}, `
      <td>${esc(k)}</td><td><span class="pill ${d.experience === 'novice' ? 'info' : ''}">${esc(d.experience)}</span></td>
      <td>${d.tasks}</td><td>${d.minutes_saved.toFixed(0)}</td>`)));
    t.appendChild(tb);
    u.appendChild(el('div', { class: 'scroll-x' })).appendChild(t);
  }
  v.appendChild(u);

  const r = el('div', { class: 'card' });
  r.innerHTML = `<h3>Risk</h3>
    <div class="grid three">
      <div class="stat"><div class="k">Unsafe actions blocked</div><div class="v">${m.risk.unsafe_actions_blocked}</div><div class="n">all causes</div></div>
      <div class="stat"><div class="k">Prompt injections caught</div><div class="v">${m.risk.prompt_injections_caught}</div><div class="n">${m.risk.quarantined_messages} message(s) quarantined</div></div>
      <div class="stat"><div class="k">DLP blocks</div><div class="v">${m.risk.dlp_blocks}</div><div class="n">restricted data stopped</div></div>
      <div class="stat"><div class="k">Permission denials</div><div class="v">${m.risk.permission_denials}</div><div class="n">scope or document access</div></div>
      <div class="stat"><div class="k">Rejected by the user</div><div class="v">${m.risk.actions_rejected_by_user}</div><div class="n">the gate doing its job</div></div>
      <div class="stat"><div class="k">Audit entries</div><div class="v">${m.risk.audit_entries}</div><div class="n">retained 13 months in production</div></div>
    </div>`;
  v.appendChild(r);

  if (m.experience.comments.length) {
    const fb = el('div', { class: 'card' });
    fb.innerHTML = '<h3>Recent feedback</h3>';
    m.experience.comments.forEach((c) => fb.appendChild(el('div', { class: 'small', style: 'padding:7px 0;border-bottom:1px solid var(--border)' },
      `<b>${c.rating === 'up' ? '&#128077;' : '&#128078;'} ${esc(c.user)}</b> &middot; <span class="muted">${fmtTime(c.at)}</span><br>${esc(c.comment)}`)));
    v.appendChild(fb);
  }
  main.appendChild(v);
}

/* -------------------------------------------------------------- about */
function viewAbout(main) {
  const v = el('div', { class: 'view' });
  v.innerHTML = `
  <header><h1>How this maps to the research</h1>
    <p>Aide is a working mock of the reference architecture in section 5 of the brief
       <i>An AI Personal Assistant for Non-Technical Employees</i>. Each finding below is
       implemented as something you can click, not as a claim in a slide.</p></header>

  <div class="card">
    <h3>Findings &rarr; what you can try</h3>
    <div class="scroll-x"><table class="data">
      <thead><tr><th>Research finding</th><th>How it shows up here</th><th>Try this</th></tr></thead>
      <tbody>
        <tr><td><b>Drafting is the highest-value start</b><br><span class="muted">Noy &amp; Zhang, Science 2023 [1]</span></td>
            <td>Reply drafting, document drafting and meeting briefs are first-class tasks with editable output.</td>
            <td class="muted">"Draft a reply to Ayesha"</td></tr>
        <tr><td><b>Largest gains for novices</b><br><span class="muted">Brynjolfsson, Li &amp; Raymond, QJE 2025 [2]</span></td>
            <td>Sam Li is a week-two joiner with fewer scopes; the Measurement tab tracks minutes saved by experience level.</td>
            <td class="muted">Sign in as Sam and ask "what should I be doing in my first two weeks?"</td></tr>
        <tr><td><b>The jagged frontier</b><br><span class="muted">Dell'Acqua et al., HBS 2023 [3]</span></td>
            <td>Confidence is shown on every answer, the reasoning trace is always open to inspection, and out-of-scope requests get a plain "I am not sure" rather than a guess.</td>
            <td class="muted">Ask something it cannot do and watch it decline</td></tr>
        <tr><td><b>RAG grounds answers in documents</b><br><span class="muted">Lewis et al., 2020 [4]</span></td>
            <td>Policy answers are extracted from approved content with numbered citations, owner and review date.</td>
            <td class="muted">"What is our travel policy for international trips?"</td></tr>
        <tr><td><b>Reason, then act with tools</b><br><span class="muted">ReAct [5], Toolformer [6]</span></td>
            <td>18 connectors in an MCP-shaped registry; every call appears in the trace with its scope.</td>
            <td class="muted">Open "How I did this" on any answer</td></tr>
        <tr><td><b>Memory under user control</b><br><span class="muted">MemGPT [7]</span></td>
            <td>The Memory tab is readable, editable and deletable; drafts change tone immediately.</td>
            <td class="muted">Change "tone" to blunt, then draft a reply</td></tr>
        <tr><td><b>Agents still fail on real office tasks</b><br><span class="muted">WorkArena [8], TheAgentCompany [9]</span></td>
            <td>No write tool ever runs on its own. Everything is staged, shown in full, editable, and approved by a person.</td>
            <td class="muted">"Book 3 days of annual leave" and inspect the card</td></tr>
        <tr><td><b>Connectors through MCP</b><br><span class="muted">Anthropic, 2024 [10]</span></td>
            <td>Tools are described with name, description, typed parameters and a read/write side effect.</td>
            <td class="muted">Permissions tab &rarr; Tool registry</td></tr>
        <tr><td><b>Indirect prompt injection is real</b><br><span class="muted">Greshake et al., 2023 [11]</span></td>
            <td>Untrusted content is scanned before the reasoning step. Two seeded messages contain hidden instructions.</td>
            <td class="muted">As Priya, "summarise my inbox", then open Safety &amp; audit</td></tr>
      </tbody></table></div>
  </div>

  <div class="card">
    <h3>The architecture, section by section</h3>
    <div class="kv">
      <div class="k">Front door</div><div>Chat plus one-click task buttons per role, and a prompt library, so nobody needs prompting skill.</div>
      <div class="k">Identity &amp; permissions</div><div>Mock SSO user switcher; delegated scopes per user; document ACLs enforced before retrieval scores anything.</div>
      <div class="k">Orchestrator</div><div>Intent router &rarr; read tools &rarr; grounded composition &rarr; staged write actions. Tool choice stays in code; only drafting is delegated to a model.</div>
      <div class="k">Knowledge layer</div><div>TF-IDF over sentence-window passages of 10 approved documents, with owner, review date and a staleness flag.</div>
      <div class="k">Tools</div><div>11 read connectors, 7 write connectors, one registry, one read/write distinction that drives the whole safety model.</div>
      <div class="k">Memory</div><div>Per-user preferences: tone, working hours, default meeting length, contacts, signature, notes.</div>
      <div class="k">Safety &amp; compliance</div><div>Injection scanning, DLP on outbound content, scope checks, full audit log, quarantine view.</div>
    </div>
  </div>

  <div class="card">
    <h3>What is deliberately mocked</h3>
    <ul class="small muted">
      <li>No real mail, calendar, HR or finance system is touched. Everything is fabricated seed data in memory.</li>
      <li>Retrieval is TF-IDF rather than embeddings - it keeps the demo dependency-free and inspectable.</li>
      <li>The default reasoning engine is a deterministic router plus templates, so the demo behaves identically every time and needs no API key. Set <code>AIDE_LLM_MODE=live</code> to have Claude write the drafting steps instead.</li>
      <li>Productivity baselines are assumptions from the brief's Discover phase, labelled as such, not measurements.</li>
      <li>State is in-process: restarting the server resets the scenario.</li>
    </ul>
  </div>`;
  main.appendChild(v);
}

boot().catch((e) => {
  document.getElementById('main').innerHTML =
    `<div class="view"><div class="notice critical"><span class="ico">&#9940;</span><div><b>Could not start</b><span>${esc(e.message)}</span></div></div></div>`;
});
