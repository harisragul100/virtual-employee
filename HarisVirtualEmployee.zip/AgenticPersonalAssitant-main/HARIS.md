# Haris's virtual employee

Aide, configured as a study-and-projects assistant. Select **Haris Ragul** in the top bar.

- **Knowledge base (private to you):** AI/ML roadmap, elective plan (JFSD -> AJDS -> MDSA), project portfolio (MIRAGE, RAG paper, drift detection), study rhythm. Edit the `doc-study-*` entries in `app/seed.py`.
- **Memory tab:** tone, study block, contacts. Editable at runtime.
- **Safety:** every send/book/save is staged for your approval; the sample internship e-mail carries a hidden instruction that gets quarantined.
- **Sample data:** Anand Rao, Kavya Nair, the inbox and diary are placeholders. Replace them, or swap `app/tools.py` bodies for real Gmail/Calendar connectors.
- **Live mode:** set `AIDE_LLM_MODE=live` and `ANTHROPIC_API_KEY` in `.env` for Claude-written drafts.

Run: `./run.sh` -> http://127.0.0.1:8000
