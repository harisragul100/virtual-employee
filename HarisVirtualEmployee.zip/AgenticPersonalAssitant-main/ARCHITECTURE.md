# Architecture

How Aide implements the reference architecture in §5 of research brief 8 of 8,
and why each design decision is the way it is.

---

## The one idea the whole thing hangs on

Every tool is marked **read** or **write**.

```python
@tool("mail.list",  ..., side_effect="read",  scope="mail.read",  ...)
@tool("mail.send",  ..., side_effect="write", scope="mail.send",  ...)
```

Read tools run inside the agent loop. Write tools **cannot** — `tools.call_read`
raises if you hand it a write tool. The only path to a write tool is
`orchestrator.approve()`, which is reachable only from an HTTP endpoint a person
triggers.

That single distinction, enforced in one place, is what the brief means by
"asks for confirmation before sending, booking, submitting or deleting anything."
It is not a prompt instruction the model might ignore on a bad day; it is a
branch in the code.

The evidence behind it is §2 of the brief: WorkArena [8] and TheAgentCompany [9]
both find that the best agents still fail a large share of ordinary office tasks.
An assistant that acts unsupervised converts those failures into sent e-mails and
submitted forms. An assistant that stages them converts them into drafts someone
glances at and fixes.

---

## Request lifecycle

```
POST /api/chat  {user_id, message}
        │
        ├─ safety.scan_untrusted(message)        the user may have pasted an attack
        ├─ llm.classify_intent(message)          weighted patterns → one of 18 intents
        ├─ llm.extract_entities(message)         people, durations, dates, amounts
        │
        ├─ HANDLERS[intent](run, entities)
        │     ├─ run.use("mail.list", …)         READ  → scope check → execute → trace
        │     │     └─ safety.scan_untrusted()   every untrusted body, before reasoning
        │     ├─ run.use("knowledge.search", …)  READ  → ACL filter → TF-IDF → citations
        │     ├─ run.write(kind, draft)          mock template, or Claude in live mode
        │     └─ run.stage("mail.send", …)       WRITE → DLP → scope → QUEUED, not run
        │
        └─ returns {answer, trace, citations, safety_notices, pending_actions, …}

POST /api/actions/{id}/approve  {edits}
        ├─ merge the human's edits
        ├─ safety.dlp_check()                    again — the human may have added something
        └─ tools.execute_write()                 the only place a write tool ever runs
```

---

## The seven layers of §5

### Front door

`web/` — one page, no build step, no framework.

The brief's enablement section asks for "ready-made prompt templates and
one-click actions, so no prompting skill is needed". `main.py` holds
`QUICK_ACTIONS` keyed by department: an HR advisor sees *Schedule the panel*,
a finance analyst sees *Explain the Q3 sheet*. The empty chat state shows a
grouped prompt library. A person who never types a full sentence can still use
every capability.

Each answer carries its confidence, its full reasoning trace, its sources and a
feedback control — the brief's "feedback button in the assistant".

### Identity and permissions

`app/safety.py` · `app/seed.py`

Two mechanisms, both enforced before anything happens rather than after:

**Delegated scopes.** Each user has a list like `["mail.read", "mail.send", …]`.
Each tool declares one required scope. `safety.check_scope` runs before every
read and before every staged write. Sam Li has no `mail.send`, so asking him to
draft a reply stages nothing and returns a plain explanation.

**Document ACLs.** Each document has `groups`. `rag.search` intersects them with
the user's groups *before scoring* — an unreadable passage is never a retrieval
candidate, so it cannot leak through a paraphrase. When relevant documents are
withheld, the count is reported and logged, so the user knows something exists
without learning what it says.

This is the brief's "the assistant acts on behalf of the user with that user's
permissions only … so it never sees files the user cannot see", implemented
literally.

### Orchestrator

`app/orchestrator.py`

A bounded ReAct loop [5]. Intent routing and tool selection stay in code; only
composition is delegated to a model. That is a deliberate trade: deterministic
routing is inspectable, testable and cheap, and the brief's benchmark evidence
argues against handing an LLM the whole loop for consequential office work.

Each of the 18 intents has a handler that reads what it needs, composes an
answer, and stages any write. The `Run` object accumulates a trace the UI renders
verbatim — routing decision and confidence, every tool call with its scope and
arguments, every safety event, every staged action. Nothing in the trace is
reconstructed for display; it is the actual execution record.

When confidence is low the run says so and keeps to read-only work.

### Knowledge layer

`app/rag.py`

TF-IDF over three-sentence windows with two-sentence overlap. Dependency-free on
purpose: every ranking decision is inspectable, and the interface is the one a
vector index would expose, so swapping it is a single function body.

Four refinements earn their place:

- **Title weighting.** A document's title says what it is about, so each title
  term is counted three extra times in every passage of that document. Without
  it, "what should I do in my first two weeks?" matches the leave policy's
  "first two weeks of January" ahead of the New Joiner Guide.
- **Digits are kept.** Single characters are dropped as noise except digits —
  "grade 4", "P1" and "5 days" all hang on the number.
- **A coverage floor.** If the best passage covers less than 34% of the
  question's IDF mass, the app returns nothing and says so. Without this,
  "what is our policy on submarine maintenance?" gets an answer about travel,
  because both contain the word "policy". Declining is the correct output.
- **Label-fragment merging.** Policies are written as "Carry-over. Up to 5
  unused days…". A naive sentence split quotes "Carry-over." back at the user as
  though it were an answer.

Answers are **extractive**: sentences lifted verbatim, each with a `[n]` marker,
and only the cited documents are listed. For a policy question that is worth more
than a fluent paraphrase the reader then has to go and verify. Every source
carries its owner and review date — the brief's "freshness and ownership
metadata" — and anything unreviewed for a year is flagged.

### Tools

`app/tools.py` — 11 read connectors, 7 write connectors.

Descriptors follow the shape MCP [10] uses: name, plain-language description,
typed parameters, plus the read/write side effect. `/api/config` exposes the
whole registry, and the Permissions tab renders it, so a non-technical reader can
see exactly what the assistant is able to touch.

### Memory

`app/store.py` · the Memory tab.

Per-user preferences — tone, working hours, default meeting length, frequent
contacts, signature, notes — read on every run. Tone drives phrasing; working
hours bound slot search; default meeting length fills in an unstated duration.

The MemGPT lesson [7] in the brief is qualified with "with user control", so
memory here is a first-class screen: readable, editable, deletable, and every
change written to the audit log. Nothing is remembered that the person cannot see.

### Safety and compliance

`app/safety.py` — three independent checks, any of which can stop a run.

**Indirect prompt injection [11].** Eleven patterns covering instruction
override, fake system messages, hidden HTML comments, exfiltration requests,
payment-redirection language and approval bypass. Untrusted content is scanned
at the tool boundary — `mail.list` and `mail.get` scan every body before
returning it — so a hidden instruction never reaches the composition step at all.
Matches are stripped, the message is quarantined, the event is logged, and the
user is told in plain language what the sender tried to do.

Two seeded messages are booby-trapped: a recruiter asking for confidential salary
bands to be forwarded outside, and a supplier invoice pushing for an unreviewed
payment to changed bank details. Both are realistic attacks, not toys.

**Data-loss prevention.** Patterns for card numbers, IBANs, government
identifiers, salary bands and reward data, classified `restricted` (never leaves)
or `confidential` (never leaves the tenant). It runs when an action is staged
**and again at approval**, because the human may paste something the assistant
never saw.

**Audit.** Every tool call, approval decision, rejection, block, denial and
memory change, with the user who caused it. The Safety tab renders it live.

---

## Measurement

`store.metrics_snapshot()` implements §7 directly.

- **Adoption** — weekly active users, tasks per user, repeat users.
- **Productivity** — minutes saved against a per-task baseline from the Discover
  phase, minus realistic review time. Labelled an assumption everywhere it
  appears, because it is one. A thumbs-down zeroes that task's saving: work the
  user rejected did not save them anything.
- **Quality** — approval rate and correction rate. The share of drafts edited
  before approval is the most honest quality signal in the system; it is
  measured, not estimated.
- **Experience** — thumbs and comments.
- **Risk** — injections caught, DLP blocks, permission denials, user rejections,
  quarantined messages, audit volume.

Usage is broken down by experience level, so the brief's finding that gains
concentrate among less-experienced staff [2] is something the deployment can
verify rather than assume.

---

## Deliberate trade-offs

| Decision | Why | Cost |
|---|---|---|
| Deterministic routing, model only for drafting | Inspectable, testable, free, identical every run; the benchmark evidence argues against full autonomy | Phrasings outside the cue patterns fall back to knowledge search |
| TF-IDF rather than embeddings | No dependencies; every ranking decision is explainable | Weak on synonyms — "time off" needs the word "leave" nearby |
| Extractive answers | A verbatim, cited sentence beats a paraphrase the reader must verify | Reads more like a policy than like prose |
| In-memory state | Resets cleanly between demos; no migrations | Nothing survives a restart |
| One approval card per write action | Each decision is separate and legible | Chasing five threads means five approvals |
| Scanning at the tool boundary | One place to get right; impossible to bypass from a handler | Slight cost on every mail read |

---

## If this became a pilot

In roughly the order the brief's rollout plan implies:

1. **Real identity** — OIDC with delegated OAuth scopes, replacing the switcher.
2. **Real connectors** — Microsoft Graph or Google Workspace behind the same
   registry. The orchestrator does not change.
3. **Real retrieval** — a vector index with the ACL filter still applied before
   scoring, plus the source metadata the UI already renders.
4. **Persistence** — `store.py` behind Postgres; the audit log to append-only
   storage with the 13-month retention the AI-use policy states.
5. **Injection defence beyond patterns** — a classifier alongside the regexes,
   provenance tracking on every retrieved span, and a hard rule that content from
   outside the tenant can never justify a write action.
6. **Evaluation** — a held-out set of real employee questions with known answers,
   run on every change, measuring citation accuracy and refusal rate. The brief's
   jagged-frontier finding [3] means you cannot know where the capability ends
   without measuring it.
