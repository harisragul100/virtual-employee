#!/usr/bin/env bash
# Aide - one-command start.  Creates the virtual environment on first run.
set -euo pipefail
cd "$(dirname "$0")"

PY=${PYTHON:-python3}
if [ ! -d .venv ]; then
  echo "==> Creating virtual environment (.venv)"
  "$PY" -m venv .venv
  .venv/bin/python -m pip install --quiet --upgrade pip
  echo "==> Installing dependencies"
  .venv/bin/python -m pip install --quiet -r requirements.txt
fi

HOST=$(grep -E '^AIDE_HOST=' .env 2>/dev/null | cut -d= -f2 || true); HOST=${HOST:-127.0.0.1}
PORT=$(grep -E '^AIDE_PORT=' .env 2>/dev/null | cut -d= -f2 || true); PORT=${PORT:-8000}

echo "==> Aide is starting on http://$HOST:$PORT"
echo "    Press Ctrl+C to stop."
exec .venv/bin/python -m uvicorn app.main:app --host "$HOST" --port "$PORT" "$@"
