# Aide — an AI personal assistant for non-technical employees

A working mock of the reference architecture in research brief 8 of 8,
*An AI Personal Assistant for Non‑Technical Employees* (September 2026).

It is a complete, runnable application: a chat front end, an agent orchestrator,
ten company documents with retrieval and citations, eighteen tool connectors,
four employees with different permissions, and the safety layer the brief calls
for. It runs offline with **no API key** and **no npm install**.

Everything in it is fabricated. It touches no real mail, calendar, HR or finance
system, and nothing leaves your machine.

---

## Contents

1. [What it does](#1-what-it-does)
2. [Quick start](#2-quick-start)
3. [Detailed build and run guide](#3-detailed-build-and-run-guide)
4. [A ten-minute guided tour](#4-a-ten-minute-guided-tour)
5. [Configuration](#5-configuration)
6. [Running with a real Claude model](#6-running-with-a-real-claude-model)
7. [Running the tests](#7-running-the-tests)
8. [Project layout](#8-project-layout)
9. [API reference](#9-api-reference)
10. [Troubleshooting](#10-troubleshooting)
11. [Extending it](#11-extending-it)
12. [What is deliberately mocked](#12-what-is-deliberately-mocked)

---

## 1. What it does

Four fictional employees at "Northwind" share one assistant:

| User | Role | Notable for the demo |
|---|---|---|
| **Priya Sharma** | HR Advisor | Can read the confidential salary bands. Her inbox contains a booby‑trapped e‑mail. |
| **Tom Okafor** | Finance Analyst | Can read the month‑end checklist, **cannot** read salary bands. Has unclaimed receipts. |
| **Dana Reyes** | Sales Ops Coordinator | Can read the discount matrix. Has a live customer negotiation. |
| **Sam Li** | Team Administrator, week 2 | A novice with **fewer delegated scopes** — he cannot send mail through the assistant at all. |

Sixteen task types are supported, each mapped to a section of the brief:

**Mail** — summarise the inbox, draft replies in your tone, chase unanswered
threads · **Diary** — find slots, book meetings, prepare briefings ·
**Knowledge** — answer company questions from company documents with citations ·
**Documents** — first drafts of reports, memos and decks · **Data** — explain a
spreadsheet in words · **Requests** — IT tickets, leave, expenses, to‑do items ·
**Onboarding** — explain internal jargon and processes.

Five things make it an *assistant for non‑technical staff* rather than a chat box:

- **One‑click tasks per role.** No prompting skill required.
- **A confirmation gate.** No write action — send, book, submit, save — ever runs
  on its own. Every one is staged with all fields editable, and a human presses
  Approve.
- **Citations on every policy answer**, with the document owner and review date.
- **Visible, editable memory.** You can read and change what it remembers.
- **A safety layer you can watch working.** Hidden instructions in incoming mail
  are stripped and quarantined; restricted data is blocked from leaving; every
  action is written to an audit log.

---

## 2. Quick start

```bash
cd aide-assistant && ./run.sh
```

Then open **http://127.0.0.1:8000**.

The first run creates a virtual environment and installs four packages (about
20 seconds). Subsequent runs start in about a second. Press `Ctrl+C` to stop.

Requirements: **Python 3.9 or newer** and an internet connection *for the first
install only*. macOS, Linux and WSL are all fine.

---

## 3. Detailed build and run guide

### Step 1 — check your Python

```bash
python3 --version
```

You need 3.9 or newer. The app is tested on the Python that ships with macOS
(3.9.6) and on 3.11/3.12. If `python3` is missing, install it from
[python.org](https://www.python.org/downloads/) or with `brew install python`.

### Step 2 — get into the project directory

```bash
cd aide-assistant
ls
```

You should see `app/`, `web/`, `tests/`, `requirements.txt` and `run.sh`.

### Step 3 — create the virtual environment

A virtual environment keeps these four packages out of your system Python.

```bash
python3 -m venv .venv
```

This creates a `.venv/` folder. You never need to "activate" it — every command
below calls `.venv/bin/python` directly, which is less error‑prone. (If you
prefer activating, `source .venv/bin/activate` works, and then plain `python`
and `pytest` will do.)

### Step 4 — install the dependencies

```bash
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
```

What gets installed and why:

| Package | Why |
|---|---|
| `fastapi` | the HTTP API |
| `uvicorn` | the web server that runs it |
| `pydantic` | request validation |
| `anthropic` | **optional** — only used in live‑LLM mode |
| `pytest`, `httpx` | tests only |

Retrieval, ranking and the reasoning engine are pure standard library — there is
no numpy, no torch, no vector database.

### Step 5 — (optional) create a config file

```bash
cp .env.example .env
```

Skip this and every default applies. See [Configuration](#5-configuration).

### Step 6 — start the server

```bash
.venv/bin/python -m uvicorn app.main:app --reload --port 8000
```

`--reload` restarts the server when you edit a file — useful while exploring the
code, and safe to drop. You should see:

```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
INFO:     Application startup complete.
```

### Step 7 — open it

Go to **http://127.0.0.1:8000** in any modern browser.

You should land on the chat view signed in as Priya Sharma, with six one‑click
task buttons across the top and three green guardrail badges in the top right.

### Step 8 — confirm it is healthy

In a second terminal:

```bash
curl -s http://127.0.0.1:8000/api/config | python3 -m json.tool | head -20
```

You should see `"engine": "mock"` and all three guardrails `true`.

### Stopping and restarting

`Ctrl+C` stops the server. State lives in memory, so **restarting resets the
whole scenario** — every draft, approval, ticket and metric. The **Reset** button
in the top right does the same thing without restarting.

---

## 4. A ten-minute guided tour

Follow this in order — it walks through every research finding the brief lists.

### Minute 1 — the confirmation gate

Signed in as **Priya**, click **Reply to Sam**.

The assistant finds Sam's message, searches the leave policy, and writes a reply
grounded in it. Below the draft is an **approval card**: amber border, "awaiting
your approval", every field editable.

Nothing has been sent. Open the **Workspace** tab and check "Sent by the
assistant" — it is empty. Come back, edit a word in the draft, and press
**Approve and run**. Now the Workspace shows it, and **Measurement** counts it as
an edited‑before‑approval correction.

> *Brief §5: "asks for confirmation before sending, booking, submitting or
> deleting anything". Brief §2: agents still fail many real office tasks
> [WorkArena, TheAgentCompany], so keep a human on the trigger.*

### Minute 3 — indirect prompt injection

Still as Priya, click **Summarise my inbox**.

A red banner appears above the summary: a hidden instruction was found in the
"Candidate pack" e‑mail from the external recruiter. The message body contained
an HTML comment telling the assistant to look up the confidential salary bands,
reply with them, and forward the thread to an outside address — without telling
Priya.

The assistant stripped it, quarantined the message, logged it, and told her.

Now ask it to **draft a reply to the recruitment inbox about the candidates**.
It writes a professional reply that declines to share reward information and
says nothing about the hidden text — and the recipient is still the original
sender, not the attacker's address.

Open **Safety & audit** to see the quarantine entry with every pattern it
matched, and the audit trail underneath.

> *Brief §5 and reference [11], Greshake et al., 2023.*

### Minute 5 — permissions are the user's, not the assistant's

Ask Priya: **"What are the salary bands for grade 4?"** — you get the figures,
cited to the confidential Reward document.

Switch to **Tom** in the top bar and ask the identical question. He gets:

> I could not find an answer in the company documents you have access to.
> 1 document matched your question but sits outside your access groups.

Same assistant, same index, different answer — because retrieval filters by the
signed‑in user's access groups *before* it scores anything.

Now switch to **Sam Li** and ask him to **draft a reply to Ayesha**. He has no
`mail.send` scope, so nothing is staged and the assistant says so plainly rather
than finding a way round.

> *Brief §5: "the assistant acts on behalf of the user with that user's
> permissions only … so it never sees files the user cannot see."*

### Minute 7 — grounded answers and honest refusals

As Tom: **"What is our travel policy for international trips?"** — you get
sentences lifted verbatim from the policy, each with a `[1]` marker, and a source
block naming the owner and the review date.

Then ask: **"What is our policy on submarine maintenance?"** — it declines
instead of padding an answer out of loosely related documents. Open "How I did
this" to see the retrieval‑coverage note explaining why.

> *Brief §2 and reference [4]: ground answers in documents; reference [3]: show
> sources and teach staff where the capability ends.*

### Minute 8 — data-loss prevention

As Priya, draft any reply, then paste this into the body of the approval card
and press Approve:

```
Grade 4 Specialist: USD 66,000 to USD 84,000, target bonus 8 percent.
```

It is refused: *Blocked by data‑loss prevention: Salary band data, Reward data.*
DLP runs again at approval time precisely because the human may have added
something the assistant never saw.

### Minute 9 — memory you can edit

Open **Memory**. Change Priya's `tone` to something blunt — for example
`blunt and brief; no pleasantries; maximum four sentences`. Save, return to
Chat, and ask for a draft reply. The opener is gone.

> *Brief §5 and reference [7], MemGPT: long‑term memory, under user control.*

### Minute 10 — measurement

Open **Measurement** for the five measures in §7 of the brief: adoption,
productivity (against per‑task baselines, labelled as assumptions),
quality (approval and correction rates), experience (thumbs), and risk
(injections caught, DLP blocks, permission denials, rejections).

Switch to **Sam Li**, run a few tasks, and note that "Who is using it" tracks
experience level — the brief's finding that the largest gains accrue to
less‑experienced staff is something you measure, not assume.

---

## 5. Configuration

Copy `.env.example` to `.env`. Everything has a working default.

| Variable | Default | What it does |
|---|---|---|
| `AIDE_LLM_MODE` | `mock` | `mock` = deterministic offline engine. `live` = Claude writes the drafting steps. |
| `ANTHROPIC_API_KEY` | *(empty)* | Only read when `AIDE_LLM_MODE=live`. |
| `AIDE_MODEL` | `claude-sonnet-5` | Model used in live mode. |
| `AIDE_HOST` | `127.0.0.1` | Bind address. |
| `AIDE_PORT` | `8000` | Port. |
| `AIDE_CONFIRM_BEFORE_ACTING` | `true` | **Demo switch.** Set `false` and write tools execute immediately. |
| `AIDE_PROMPT_INJECTION_DEFENCE` | `true` | **Demo switch.** Set `false` and hidden instructions reach the reasoning step. |
| `AIDE_DLP` | `true` | **Demo switch.** Set `false` to disable outbound content checks. |

The three switches exist so you can *show* what the guardrails prevent. Turn one
off and the badge in the top right turns red. Turn `AIDE_CONFIRM_BEFORE_ACTING`
off, ask for a reply, and it is sent before you have read it — which is the
argument for the gate, made in one click.

Restart the server after editing `.env`.

---

## 6. Running with a real Claude model

Mock mode is the default because it is deterministic, free and offline. Live mode
hands the *drafting* steps to Claude while intent routing, tool selection and the
confirmation gate stay in code.

```bash
cp .env.example .env
# edit .env:
#   AIDE_LLM_MODE=live
#   ANTHROPIC_API_KEY=sk-ant-...
#   AIDE_MODEL=claude-sonnet-5
./run.sh
```

The engine badge in the top bar changes from `engine: mock (offline)` to
`engine: live:claude-sonnet-5`.

What changes: replies, briefs, reports, daily plans and policy answers are
rewritten in the user's tone, grounded in the retrieved passages, with every
figure and citation preserved. What does not change: which tools run, what gets
staged, and every safety check. If the API call fails for any reason, the
deterministic draft is used instead — the app never breaks because a model call
did.

---

## 7. Running the tests

```bash
.venv/bin/python -m pytest -q
```

39 tests, under a second. They cover the behaviours the brief actually asks for,
not just the plumbing:

- write tools are staged and **never** executed inside a run
- approval executes, records edits, and cannot happen twice
- rejection executes nothing
- retrieval respects the signed‑in user's access groups
- a missing scope blocks the tool and says so
- hidden instructions are stripped, quarantined and logged
- a reply to a poisoned message leaks neither the salary data nor the address
- DLP blocks restricted content added at approval time
- citation markers resolve to real sources
- the assistant declines rather than inventing an answer
- questions *about* a rule do not trigger the action the rule governs
- memory edits change the output
- the five §7 measures are all populated

Useful variations:

```bash
.venv/bin/python -m pytest -v                      # one line per test
.venv/bin/python -m pytest -k injection            # just the injection tests
.venv/bin/python -m pytest -k "approval or scope"  # the gate and permissions
```

---

## 8. Project layout

```
aide-assistant/
├── run.sh                  One-command start; creates the venv on first run
├── requirements.txt
├── .env.example            Every setting, with defaults
│
├── app/
│   ├── main.py             FastAPI routes + static hosting + role prompt library
│   ├── config.py           Settings, .env loader, guardrail switches
│   ├── seed.py             The fictional company: people, documents, mail, diary
│   ├── store.py            In-process state, audit log, the §7 metrics
│   ├── rag.py              Retrieval: TF-IDF over sentence windows, ACL-filtered
│   ├── safety.py           Injection scanning, DLP, delegated-scope checks
│   ├── llm.py              Intent routing, entity extraction, mock/live drafting
│   ├── tools.py            The 18 connectors, each marked read or write
│   └── orchestrator.py     The agent loop and the confirmation gate
│
├── web/
│   ├── index.html          Single page, no build step
│   ├── styles.css          Light and dark, no framework
│   └── app.js              Views, markdown renderer, approval cards
│
└── tests/test_app.py       39 tests
```

The two files worth reading first are **`app/orchestrator.py`** (the agent loop
and, in `Run.stage`, the confirmation gate) and **`app/safety.py`** (all three
defences, about 150 lines).

---

## 9. API reference

Interactive docs are generated automatically at
**http://127.0.0.1:8000/docs** while the server runs.

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/api/config` | Engine, guardrail states, full tool registry |
| `GET` | `/api/users` | The four demo employees |
| `GET` | `/api/session/{user_id}` | Scopes, visible corpus, memory, quick actions |
| `POST` | `/api/chat` | Run a turn: `{user_id, message}` |
| `GET` | `/api/actions?user_id=&status=` | Staged actions |
| `POST` | `/api/actions/{id}/approve` | Execute, with optional `{edits: {...}}` |
| `POST` | `/api/actions/{id}/reject` | Decline, with an optional reason |
| `GET` | `/api/memory/{user_id}` | Read memory |
| `POST` | `/api/memory` | Write one memory key |
| `DELETE` | `/api/memory/{user_id}/{key}` | Forget one key |
| `GET` | `/api/knowledge/{user_id}` | Documents this user may read |
| `GET` | `/api/workspace/{user_id}` | Inbox, sent, diary, tickets, claims, docs |
| `GET` | `/api/safety` | Quarantine and audit log |
| `GET` | `/api/metrics` | The five §7 measures |
| `POST` | `/api/feedback` | Thumbs and a comment |
| `POST` | `/api/reset` | Restore the scenario |

Driving it from the command line:

```bash
curl -s -X POST http://127.0.0.1:8000/api/chat \
  -H 'Content-Type: application/json' \
  -d '{"user_id":"tom.okafor","message":"What is our travel policy for international trips?"}' \
  | python3 -c 'import json,sys; r=json.load(sys.stdin); print(r["answer"])'
```

---

## 10. Troubleshooting

**`command not found: python3`** — install Python 3.9+ from python.org, or
`brew install python` on macOS.

**`Address already in use`** — something else holds port 8000. Either
`./run.sh --port 8080`, or find it: `lsof -i :8000`.

**`ModuleNotFoundError: No module named 'fastapi'`** — you are running the system
Python instead of the virtual environment. Use `.venv/bin/python -m uvicorn ...`,
not `python -m uvicorn ...`.

**`./run.sh: Permission denied`** — `chmod +x run.sh`.

**The page loads but stays blank** — open the browser console. The most common
cause is the server having been started from the wrong directory; `app.main:app`
must be resolvable from where you ran it, so start from inside `aide-assistant/`.

**Changes to `web/` do not show** — hard‑refresh the browser
(`Cmd+Shift+R` / `Ctrl+Shift+R`). `--reload` watches Python, not static files.

**Everything disappeared after a restart** — expected. State is in memory by
design; see [§12](#12-what-is-deliberately-mocked).

**Live mode behaves exactly like mock mode** — the key is missing or the package
is not installed. Check `/api/config`: `live_llm_available` must be `true`.

---

## 11. Extending it

**Add a company document** — append a dict to `DOCUMENTS` in `app/seed.py` with
`groups` (the access control list), `owner` and `last_reviewed`. The index
rebuilds on the next server start; nothing else to do.

**Add a tool** — decorate a function in `app/tools.py`:

```python
@tool("crm.create_lead", "Create a CRM lead", "Add a lead to the CRM.",
      side_effect="write", scope="crm.write", system="CRM",
      params={"company": "str", "value": "float"})
def crm_create_lead(user_id: str, args: dict) -> dict:
    ...
    return {"created": True, "receipt": "Lead created"}
```

`side_effect="write"` is all it takes to put the tool behind the approval gate.
Add `crm.write` to a user's `scopes` in `seed.py` to let them use it.

**Add a task type** — add cue patterns to `INTENTS` in `app/llm.py`, write a
`_h_<name>(run, entities)` handler in `app/orchestrator.py`, and register it in
`HANDLERS`. Use `run.use(...)` for reads and `run.stage(...)` for anything that
changes the world.

**Swap in real retrieval** — replace the body of `rag.search`. Keep the ACL
filter *before* scoring and keep returning `title`, `owner`, `url`,
`last_reviewed` and `snippet`, and the rest of the app is unaffected.

**Swap in real connectors** — replace the function bodies in `app/tools.py` with
Microsoft Graph, Google Workspace or MCP calls. The orchestrator never touches a
system directly; it only ever goes through the registry.

**Persist state** — `app/store.py` is the only module holding mutable state.
Back it with SQLite or Postgres and nothing else changes.

---

## 12. What is deliberately mocked

Being explicit about this matters more than the demo looking impressive:

- **No real systems.** Mail, diary, HR, finance and the service desk are
  fabricated Python dictionaries. No network call leaves the machine in mock mode.
- **Retrieval is TF‑IDF, not embeddings.** It keeps the app dependency‑free and
  every ranking decision inspectable. A production build would use a vector
  index — the interface is the same.
- **The default engine is deterministic.** Intent routing is a weighted pattern
  matcher and drafts come from templates, so the demo behaves identically every
  time and needs no API key. Live mode swaps in Claude for the drafting steps.
- **Productivity baselines are assumptions**, drawn from the Discover phase the
  brief describes, and labelled as such in the UI. They are not measurements of
  this application.
- **State is in‑process.** Restarting resets everything. That is a feature for a
  demo and the first thing you would change for a pilot.
- **Identity is a user switcher, not SSO.** The permission *model* — delegated
  scopes and document ACLs enforced before retrieval — is real; the sign‑in is not.

---

## Research the application implements

1. Noy, S., & Zhang, W. (2023). Experimental evidence on the productivity effects of generative artificial intelligence. *Science*, 381(6654), 187–192.
2. Brynjolfsson, E., Li, D., & Raymond, L. (2025). Generative AI at work. *QJE*, 140(2), 889–942.
3. Dell'Acqua, F., McFowland, E., Mollick, E., et al. (2023). Navigating the jagged technological frontier. HBS Working Paper 24‑013.
4. Lewis, P., Perez, E., Piktus, A., et al. (2020). Retrieval-augmented generation for knowledge-intensive NLP tasks. NeurIPS 2020.
5. Yao, S., Zhao, J., Yu, D., et al. (2023). ReAct: Synergizing reasoning and acting in language models. ICLR 2023.
6. Schick, T., Dwivedi-Yu, J., Dessì, R., et al. (2023). Toolformer. NeurIPS 2023.
7. Packer, C., Wooders, S., Lin, K., et al. (2023). MemGPT: Towards LLMs as operating systems.
8. Drouin, A., Gasse, M., Caccia, M., et al. (2024). WorkArena. ICML 2024.
9. Xu, F. F., Song, Y., Li, B., et al. (2024). TheAgentCompany.
10. Anthropic (2024). Introducing the Model Context Protocol.
11. Greshake, K., Abdelnabi, S., Mishra, S., et al. (2023). Not what you've signed up for: compromising real-world LLM-integrated applications with indirect prompt injection. ACM AISec 2023.

See **ARCHITECTURE.md** for how each of these maps onto a specific file and
function, and for the design decisions behind the orchestrator.
